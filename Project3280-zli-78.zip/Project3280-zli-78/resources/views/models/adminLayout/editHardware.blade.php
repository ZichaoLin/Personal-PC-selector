@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])

<section class="section">
<form class="box" method="POST" action="{{route('UpdateHardware',[$viewData['productsName'],$viewData['product']->ID])}}">
@csrf  
<div class="field">
<label class="label">ID</label>
            <div class="control">
                <input class="input" name="ID" type="text" value="{{$viewData['product']->ID}}" placeholder="ID" required>
            </div>
 </div>
<div class="field">
<label class="label">Title</label>
            <div class="control">
                <input class="input" name="name" type="name" value="{{$viewData['product']->Name}}" placeholder="Title" required>
            </div>
 </div>
 <div class="field">
<label class="label">Price</label>
            <div class="control">
                <input class="input" name="Price" max="999999.99" step="0.01" type="number" value="{{$viewData['product']->Price}}" placeholder="Price" required>
            </div>
 </div>
 <div class="field">
<label class="label">URL</label>
            <div class="control">
                <input class="input" name="URL" type="url" value="{{$viewData['product']->URL}}" placeholder="https://example.com" required>
            </div>
 </div>
 <label class="label">ImageURL</label>
            <div class="control">
                <input class="input" name="ImageURL" type="url" value="{{$viewData['product']->ImageURL}}" placeholder="https://example.com" required>
            </div>
 </div>
 <br>
        <button class="button is-primary">Save</button>

</form>


</section>

@extends('layout.footer')