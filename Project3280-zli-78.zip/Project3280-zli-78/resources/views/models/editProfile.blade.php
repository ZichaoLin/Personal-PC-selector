@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])
<div style="margin: 8%;">
    <h1 class="title has-text-centered" >You can edit your profile here</h1>
    <form class="box" method="POST" action="{{ route('EditProfile') }}">
        @csrf
        <div class="field">
            <label class="label">Name</label>
            <div class="control">
                <input class="input" name="name" type="name" placeholder="e.g. alex" value={{Auth::user()->name}}>
                @error('name')
                <span class="has-text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <div class="field">
            <label class="label">Email</label>
            <div class="control">
                <input class="input" name="email" type="email" placeholder="e.g. alex@example.com" value={{Auth::user()->email}}>
                @error('email')
                <span class="has-text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <div class="field">
            <label class="label">New Password</label>
            <div class="control">
                <input class="input" name="new_password" type="password" placeholder="********">
                @error('new_password')
                <span class="has-text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <div class="field">
            <label class="label">Confirm Password</label>
            <div class="control">
                <input class="input" name="new_password_confirmation" type="password" placeholder="********">
            </div>
        </div>

        <button class="button is-primary">Save</button>
    </form>
</div>
@extends('layout.footer')