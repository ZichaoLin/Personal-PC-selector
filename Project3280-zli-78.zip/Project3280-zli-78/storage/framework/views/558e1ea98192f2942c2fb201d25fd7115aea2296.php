<?php $__env->startSection('title',$viewData['title']); ?>


<link rel="stylesheet" href=<?php echo e(URL('css/main.css')); ?> type="text/css" />

<script src=<?php echo e(URL("js/jquery.min.js")); ?>></script>
<script src=<?php echo e(URL("js/jquery.poptrox.min.js")); ?>></script>
<script src=<?php echo e(URL("js/browser.min.js")); ?>></script>
<script src=<?php echo e(URL("js/breakpoints.min.js")); ?>></script>
<script src=<?php echo e(URL("js/util.js")); ?>></script>
<script src=<?php echo e(URL("js/main.js")); ?>></script>


<body class="is-preload">

    <!-- Header -->
    <header id="header">
        <div class="inner">
            <a href="#" class="image avatar"><img src="images/avatar.jpg" alt="" /></a>
            <h1>Welcome!<strong> <?php echo e($viewData['name']); ?></strong><br />
                Thank you for using our PC custom software<br />

        </div>
    </header>

    <!-- Main -->
    <div id="main">

        <!-- One -->
        <section id="one">
            <header class="major">
                <h2>Customize your ultra-powerful personal PC with our software</h2>
            </header>
            <p>Accumsan orci faucibus id eu lorem semper. Eu ac iaculis ac nunc nisi lorem vulputate lorem neque cubilia
                ac in adipiscing in curae lobortis tortor primis integer massa adipiscing id nisi accumsan pellentesque
                commodo blandit enim arcu non at amet id arcu magna. Accumsan orci faucibus id eu lorem semper nunc nisi
                lorem vulputate lorem neque cubilia.</p>
            <ul class="actions">
                <li><a href="#" class="button">Learn More</a></li>
            </ul>
        </section>

        <!-- Two -->
        <section id="two">
            <h2>Hardware Preview</h2>
            <div class="row">
                <article class="col-6 col-12-xsmall work-item">
                    <a href="images/fulls/01.jpg" class="image fit thumb"><img src="images/thumbs/01.jpg" alt="" /></a>
                    <h3>Magna sed consequat tempus</h3>
                    <p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
                </article>
                <article class="col-6 col-12-xsmall work-item">
                    <a href="images/fulls/02.jpg" class="image fit thumb"><img src="images/thumbs/02.jpg" alt="" /></a>
                    <h3>Ultricies lacinia interdum</h3>
                    <p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
                </article>
                <article class="col-6 col-12-xsmall work-item">
                    <a href="images/fulls/03.jpg" class="image fit thumb"><img src="images/thumbs/03.jpg" alt="" /></a>
                    <h3>Tortor metus commodo</h3>
                    <p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
                </article>
                <article class="col-6 col-12-xsmall work-item">
                    <a href="images/fulls/04.jpg" class="image fit thumb"><img src="images/thumbs/04.jpg" alt="" /></a>
                    <h3>Quam neque phasellus</h3>
                    <p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
                </article>
                <article class="col-6 col-12-xsmall work-item">
                    <a href="images/fulls/05.jpg" class="image fit thumb"><img src="images/thumbs/05.jpg" alt="" /></a>
                    <h3>Nunc enim commodo aliquet</h3>
                    <p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
                </article>
                <article class="col-6 col-12-xsmall work-item">
                    <a href="images/fulls/06.jpg" class="image fit thumb"><img src="images/thumbs/06.jpg" alt="" /></a>
                    <h3>Risus ornare lacinia</h3>
                    <p>Lorem ipsum dolor sit amet nisl sed nullam feugiat.</p>
                </article>
            </div>
            <ul class="actions">
                <li><a href="#" class="button">Full Portfolio</a></li>
            </ul>
        </section>

        <!-- Three -->
        <section id="three">
            <h2>Get In Touch</h2>
            <p>Accumsan pellentesque commodo blandit enim arcu non at amet id arcu magna. Accumsan orci faucibus id eu
                lorem semper nunc nisi lorem vulputate lorem neque lorem ipsum dolor.</p>
            <div class="row">
                <div class="col-8 col-12-small">
                    <form method="post" action="#">
                        <div class="row gtr-uniform gtr-50">
                            <div class="col-6 col-12-xsmall"><input type="text" name="name" id="name" placeholder="Name" /></div>
                            <div class="col-6 col-12-xsmall"><input type="email" name="email" id="email" placeholder="Email" /></div>
                            <div class="col-12"><textarea name="message" id="message" placeholder="Message" rows="4"></textarea></div>
                        </div>
                    </form>
                    <ul class="actions">
                        <li><input type="submit" value="Send Message" /></li>
                    </ul>
                </div>
                <div class="col-4 col-12-small">
                    <ul class="labeled-icons">
                        <li>
                            <h3 class="icon solid fa-home"><span class="label">Address</span></h3>
                            1234 Somewhere Rd.<br />
                            Nashville, TN 00000<br />
                            United States
                        </li>
                        <li>
                            <h3 class="icon solid fa-mobile-alt"><span class="label">Phone</span></h3>
                            000-000-0000
                        </li>
                        <li>
                            <h3 class="icon solid fa-envelope"><span class="label">Email</span></h3>
                            <a href="#">hello@untitled.tld</a>
                        </li>
                    </ul>
                </div>
            </div>
        </section>

        <!-- Four -->

        <section id="four">
            <h2>Elements</h2>




            <section>
                <h4>Your information</h4>
                <h5>Computer</h5>
                <div class="table-wrapper">
                    <table>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Item One</td>
                                <td>Ante turpis integer aliquet porttitor.</td>
                                <td>29.99</td>
                            </tr>
                            <tr>
                                <td>Item Two</td>
                                <td>Vis ac commodo adipiscing arcu aliquet.</td>
                                <td>19.99</td>
                            </tr>
                            <tr>
                                <td>Item Three</td>
                                <td> Morbi faucibus arcu accumsan lorem.</td>
                                <td>29.99</td>
                            </tr>
                            <tr>
                                <td>Item Four</td>
                                <td>Vitae integer tempus condimentum.</td>
                                <td>19.99</td>
                            </tr>
                            <tr>
                                <td>Item Five</td>
                                <td>Ante turpis integer aliquet porttitor.</td>
                                <td>29.99</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2"></td>
                                <td>100.00</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <h5>Favorite Hardware</h5>
                <div class="table-wrapper">
                    <table class="alt">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Item One</td>
                                <td>Ante turpis integer aliquet porttitor.</td>
                                <td>29.99</td>
                            </tr>
                            <tr>
                                <td>Item Two</td>
                                <td>Vis ac commodo adipiscing arcu aliquet.</td>
                                <td>19.99</td>
                            </tr>
                            <tr>
                                <td>Item Three</td>
                                <td> Morbi faucibus arcu accumsan lorem.</td>
                                <td>29.99</td>
                            </tr>
                            <tr>
                                <td>Item Four</td>
                                <td>Vitae integer tempus condimentum.</td>
                                <td>19.99</td>
                            </tr>
                            <tr>
                                <td>Item Five</td>
                                <td>Ante turpis integer aliquet porttitor.</td>
                                <td>29.99</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2"></td>
                                <td>100.00</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </section>

            <section>
                <h4>Buttons</h4>
                <ul class="actions">
                    <li><a href="#" class="button primary">Primary</a></li>
                    <li><a href="#" class="button">Default</a></li>
                </ul>
                <ul class="actions">
                    <li><a href="#" class="button large">Large</a></li>
                    <li><a href="#" class="button">Default</a></li>
                    <li><a href="#" class="button small">Small</a></li>
                </ul>
                <ul class="actions fit">
                    <li><a href="#" class="button primary fit">Fit</a></li>
                    <li><a href="#" class="button fit">Fit</a></li>
                </ul>
                <ul class="actions fit small">
                    <li><a href="#" class="button primary fit small">Fit + Small</a></li>
                    <li><a href="#" class="button fit small">Fit + Small</a></li>
                </ul>
                <ul class="actions">
                    <li><a href="#" class="button primary icon solid fa-download">Icon</a></li>
                    <li><a href="#" class="button icon solid fa-download">Icon</a></li>
                </ul>
                <ul class="actions">
                    <li><span class="button primary disabled">Primary</span></li>
                    <li><span class="button disabled">Default</span></li>
                </ul>
            </section>

            <section>
                <h4>Form</h4>
                <form method="post" action="#">
                    <div class="row gtr-uniform gtr-50">
                        <div class="col-6 col-12-xsmall">
                            <input type="text" name="demo-name" id="demo-name" value="" placeholder="Name" />
                        </div>
                        <div class="col-6 col-12-xsmall">
                            <input type="email" name="demo-email" id="demo-email" value="" placeholder="Email" />
                        </div>
                        <div class="col-12">
                            <select name="demo-category" id="demo-category">
                                <option value="">- Category -</option>
                                <option value="1">Manufacturing</option>
                                <option value="1">Shipping</option>
                                <option value="1">Administration</option>
                                <option value="1">Human Resources</option>
                            </select>
                        </div>
                        <div class="col-4 col-12-small">
                            <input type="radio" id="demo-priority-low" name="demo-priority" checked>
                            <label for="demo-priority-low">Low Priority</label>
                        </div>
                        <div class="col-4 col-12-small">
                            <input type="radio" id="demo-priority-normal" name="demo-priority">
                            <label for="demo-priority-normal">Normal Priority</label>
                        </div>
                        <div class="col-4 col-12-small">
                            <input type="radio" id="demo-priority-high" name="demo-priority">
                            <label for="demo-priority-high">High Priority</label>
                        </div>
                        <div class="col-6 col-12-small">
                            <input type="checkbox" id="demo-copy" name="demo-copy">
                            <label for="demo-copy">Email me a copy of this message</label>
                        </div>
                        <div class="col-6 col-12-small">
                            <input type="checkbox" id="demo-human" name="demo-human" checked>
                            <label for="demo-human">I am a human and not a robot</label>
                        </div>
                        <div class="col-12">
                            <textarea name="demo-message" id="demo-message" placeholder="Enter your message" rows="6"></textarea>
                        </div>
                        <div class="col-12">
                            <ul class="actions">
                                <li><input type="submit" value="Send Message" class="primary" /></li>
                                <li><input type="reset" value="Reset" /></li>
                            </ul>
                        </div>
                    </div>
                </form>
            </section>

            <section>
                <h4>Image</h4>
                <h5>Fit</h5>
                <div class="box alt">
                    <div class="row gtr-50 gtr-uniform">
                        <div class="col-12"><span class="image fit"><img src="images/fulls/05.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/01.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/02.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/03.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/04.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/05.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/06.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/03.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/02.jpg" alt="" /></span>
                        </div>
                        <div class="col-4"><span class="image fit"><img src="images/thumbs/01.jpg" alt="" /></span>
                        </div>
                    </div>
                </div>
                <h5>Left &amp; Right</h5>
                <p><span class="image left"><img src="images/avatar.jpg" alt="" /></span>Fringilla nisl. Donec accumsan
                    interdum nisi, quis tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in
                    faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu
                    faucibus. Integer ac pellentesque praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum
                    ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing
                    accumsan eu faucibus. Integer ac pellentesque praesent. Donec accumsan interdum nisi, quis tincidunt
                    felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit
                    adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque
                    praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus
                    vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer
                    ac pellentesque praesent.</p>
                <p><span class="image right"><img src="images/avatar.jpg" alt="" /></span>Fringilla nisl. Donec accumsan
                    interdum nisi, quis tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in
                    faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu
                    faucibus. Integer ac pellentesque praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum
                    ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing
                    accumsan eu faucibus. Integer ac pellentesque praesent. Donec accumsan interdum nisi, quis tincidunt
                    felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit
                    adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque
                    praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus
                    vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer
                    ac pellentesque praesent.</p>
            </section>

        </section>


    </div>

    
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\300304378\Desktop\project-3280\resources\views/welcome.blade.php ENDPATH**/ ?>