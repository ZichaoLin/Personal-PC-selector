<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title><?php echo $__env->yieldContent('title'); ?></title>

</head>

<body>
  <section class="section">
    <div class="container"><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/layout/header.blade.php ENDPATH**/ ?>