<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
<nav class="navbar" role="navigation" aria-label="main navigation">
  <div class="navbar-brand">
    <a class="navbar-item" href="">
      <img src=<?php echo e(URL("images/icon.png")); ?> width="60" height="30">
    </a>

    <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
    </a>
  </div>

  <div id="navbarBasicExample" class="navbar-menu">
    <div class="navbar-start">
      <a class="navbar-item" href="/welcome">
        Home
      </a>

      <a class="navbar-item">
        Build a Computer
      </a>

      <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link">
          More
        </a>

        <div class="navbar-dropdown">
          <a class="navbar-item">
            view my computers
          </a>
          <a class="navbar-item">
            Compare computers
          </a>
          <a class="navbar-item" href="/products">
            Look for Hardware
          </a>
          <hr class="navbar-divider">
          <a class="navbar-item">
            Contact us
          </a>
        </div>

      </div>
      <?php if(Auth::user()&&Auth::user()->Admin): ?>
      <div class="navbar-item has-dropdown is-hoverable">
      <a class="navbar-link" >
        Admin Option
      </a>
      <div class="navbar-dropdown">
          <a class="navbar-item" href="<?php echo e(route('Userdatabase')); ?>">
            View user database
          </a>
          <a class="navbar-item" href="<?php echo e(route('CreateUserPage')); ?>">
            Create user
          </a>
          <a class="navbar-item" href="<?php echo e(route('ComputerDatabase')); ?>">
            View Computers database
          </a>
      </div>
      </div>
      <?php endif; ?>
    </div>
    <div style="margin: auto;">
      <?php if(Auth::user()): ?>
      <?php if(Auth::user()->Admin): ?>
      <h1 class="title">Welcome! Admin <?php echo e(Auth::user()->name); ?></h1>
      <?php else: ?>
      <h1 class="title">Welcome <?php echo e(Auth::user()->name); ?></h1>
      <?php endif; ?>
      <?php else: ?>
      <h1 class="title">Welcome Guest</h1>
      <?php endif; ?>
    </div>
    <div class="navbar-end">
      <div class="navbar-item">
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
        <span>Edit profile</span>
        <a class="navbar-item" href="<?php echo e(route('Profilepage')); ?>">
          <img src=<?php echo e(URL("images/edit_icon.png")); ?> width="40" height="30">
        </a>
        <?php endif; ?>
        <div class="buttons">
          <?php if(auth()->guard()->guest()): ?>
          <a class="button is-primary" href="<?php echo e(route('register')); ?>">
            <strong>Sign up</strong>
          </a>
          <a class="button is-light" href=" <?php echo e(route('login')); ?>">
            Log in
          </a>
          <?php else: ?>
          <a href=" <?php echo e(route('logout')); ?>" class="button is-ligh">Logout</a>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</nav><?php /**PATH C:\Users\300304378\Desktop\Project3280-11-27\resources\views/layout/navbar.blade.php ENDPATH**/ ?>