
<?php echo $__env->make("layout.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection("title",$viewData['title']); ?>

<link rel="stylesheet" href=<?php echo e(URL('css/card.css')); ?> type="text/css">
<?php if(isset($viewData['Products'])): ?>
<h1 class="title cardTitle">Select your <?php echo e($viewData['nextProduct']); ?></h1>

  
<section class="section">
	
	<div class="container">
		
    <?php $__currentLoopData = $viewData['Products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($product->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($product->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($product->Price!=NULL)? $product->Price."$": "unavailable"); ?></p>
						<form id="sendData" method="POST" action="<?php echo e(route('addHardware')); ?>">
     						<?php echo csrf_field(); ?>
     						 <input type="hidden" name="computerName" value="<?php echo e($postData['computerName']); ?>">
	 						 <input type="hidden" name="computerDescription" value="<?php echo e($postData['computerDescription']); ?>">
							<input type="hidden" name="lastProduct" value="<?php echo e($viewData['nextProduct']); ?>">
							   <input type="hidden" name="<?php echo e('ID'); ?>" value="<?php echo e($product->ID); ?>">
							<input type="hidden" name="CPUID" value="<?php echo e(($postData['CPUID']!=null)? $postData['CPUID']: $viewData['CPUID']); ?>">
							<input type="hidden" name="MotherboardID" value="<?php echo e(($postData['MotherboardID']!=null)? $postData['MotherboardID']: $viewData['MotherboardID']); ?>">
							<input type="hidden" name="Graphics_CardID" value="<?php echo e(($postData['Graphics_CardID']!=null)? $postData['Graphics_CardID']: $viewData['Graphics_CardID']); ?>">
							<input type="hidden" name="Power_SupplyID" value="<?php echo e(($postData['Power_SupplyID']!=null)? $postData['Power_SupplyID']: $viewData['Power_SupplyID']); ?>">
							<input type="hidden" name="Hard_DiskID" value="<?php echo e(($postData['Hard_DiskID']!=null)? $postData['Hard_DiskID']: $viewData['Hard_DiskID']); ?>"> 
							
							<?php if($product->Price!=NULL): ?>
							<button class="button is-info" >Add</button>
                            <?php else: ?>
                            <?php endif; ?>
						</form>
					</div>
				</div>

				<div class="content">
					
					<a href="<?php echo e($product->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
       
	</div>
	</section>
	
	<?php else: ?>
		<article class="message is-danger">
  <div class="message-header">
    <p>Error</p>
    <button class="delete" aria-label="delete"></button>
  </div>
  <div class="message-body ">
  	No products found, please confirm whether the <strong>keywords</strong> are correct.
  </div>
</article>
	<?php endif; ?>		


<?php echo $__env->make("layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/BuildComputerPages/addHardware.blade.php ENDPATH**/ ?>