
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title',$viewData['title']); ?>
<link rel="stylesheet" href=<?php echo e(URL('css/card.css')); ?> type="text/css">
<section class="section ">
    <div class="box">
<div class="has-text-centered ">
    <p class="title">Hardware Database</p>

<div class="tabs">
  <ul>
    <li class=<?php echo e($viewData['productsName']=='CPU'? 'is-active' : ''); ?>><a href="<?php echo e(route('HardwareDatabase','CPU')); ?>">CPU</a></li>
    <li class=<?php echo e($viewData['productsName']=='Motherboard'? 'is-active' : ''); ?>><a href="<?php echo e(route('HardwareDatabase','Motherboard')); ?>">Motherboard</a></li>
    <li class=<?php echo e($viewData['productsName']=='Graphic'? 'is-active' : ''); ?>><a href="<?php echo e(route('HardwareDatabase','Graphic')); ?>">Graphic Card</a></li>
    <li class=<?php echo e($viewData['productsName']=='Power'? 'is-active' : ''); ?>><a href="<?php echo e(route('HardwareDatabase','Power')); ?>">Power</a></li>
    <li class=<?php echo e($viewData['productsName']=='Memory'? 'is-active' : ''); ?>><a href="<?php echo e(route('HardwareDatabase','Memory')); ?>">Memory</a></li>
    <li class=<?php echo e($viewData['productsName']=='HardDisk'? 'is-active' : ''); ?>><a href="<?php echo e(route('HardwareDatabase','HardDisk')); ?>">HardDisk</a></li>
  </ul>
</div>
</div>
<?php if(isset($viewData['products'])): ?>
<section class="section">
<div class="container">
<?php $__currentLoopData = $viewData['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($product->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($product->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($product->Price!=null)? $product->Price: "unavailable"); ?></p>
					</div>
				</div>

				<div class="content">
					
					<a class="button is-danger" href="<?php echo e(route('DeleteHardware',[$viewData['productsName'],$product->ID])); ?>">Delete</a>
                    <a class="button is-info" href="<?php echo e(route('EditHardware',[$viewData['productsName'],$product->ID])); ?>">Edit</a>		
				</div>
			</div>
		</div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
        <div class="card has-text-centered">
       
			<div class="card-content">
			

				<div class="content">
                <a class="button is-primary " href="<?php echo e(route('AddHardware',$viewData['productsName'])); ?>">Add</a>
              
				</div>
			</div>
        	</div>
        
</div>   
</section>
	<?php else: ?>
		<article class="message is-danger">
  <div class="message-header">
    <p>Error</p>
    <button class="delete" aria-label="delete"></button>
  </div>
  <div class="message-body ">
  	No products found, please Add product to database<strong></strong> 
  </div>
</article>
	<?php endif; ?>		




    </div>
</section>



<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/adminLayout/HardwareDatabase.blade.php ENDPATH**/ ?>