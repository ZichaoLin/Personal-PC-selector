@extends('layout.header')
@include('layout.navbar')
<link rel="stylesheet" href={{URL('css/style.css')}} type="text/css">
<form class="box" method="POST" action="{{ route('CreateUser') }}">
    @csrf
    <h1>CreateAccount</h1>
    <input id="name" type="text" name="name" value="{{ old('name') }}" placeholder="Name" required autocomplete="name" autofocus>
    @error('name')
    <span>
        <strong class="error-message">{{ $message }}</strong>
    </span>
    @enderror
    <input id="email" type="email" name="email" placeholder="Email Address" value="{{ old('email') }}" required autocomplete="email" autofocus>
    @error('email')
    <span>
        <strong class="error-message">{{ $message }}</strong>
    </span>
    @enderror
    <input id="password" placeholder="Password" type="password" name="password" required autocomplete="current-password">
    @error('password')
    <span>
        <strong class="error-message">{{ $message }}</strong>
    </span>
    @enderror
    
    <input id="password-confirm" type="password" placeholder="Confirm Password" name="password_confirmation" required autocomplete="new-password">
    
    <input class="form-check-input" type="checkbox" name="Admin" id="Admin">
        <label for="Admin">
        <span>Admin</span>
    </label>

    <input type="submit" name="" value="Create">

</form>
