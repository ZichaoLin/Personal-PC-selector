
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title',$viewData['title']); ?>


<link rel="stylesheet" href=<?php echo e(URL('css/card.css')); ?> type="text/css">
<section class="section box">
<?php if(isset($msg)): ?>
<article class="message is-primary">
  <div class="message-header">
    <p>Success</p>
    <a href="<?php echo e(route('EditComputer',$viewData['computer']->id)); ?>" class="delete" aria-label="delete"></a>
  </div>
  <div class="message-body ">
  	<?php echo e($msg); ?>

  </div>
</article>
<?php else: ?>
<?php endif; ?>
<form action="<?php echo e(route('EditComputerinfo',$viewData['computer']->id)); ?>" method="POST">
	<?php echo csrf_field(); ?>
<div class="field">
  <label class="label" >Name</label>
  <div class="control">
    <input class="input" type="text" name="Name" value="<?php echo e($viewData['computer']->Name); ?>" placeholder="Text input">
  </div>
</div>
<div class="field">
  <label class="label">Description</label>
  <div class="control">
    <textarea class="textarea" name="Description"  placeholder="Textarea"><?php echo e($viewData['computer']->Description); ?></textarea>
  </div>
</div>
<div class="field is-grouped">
  <div class="control">
    <button class="button is-link">
        Save
    </button>
  </div>
</div>
</form>
</section>
<div class="container">	
       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($viewData['CPU']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($viewData['CPU']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($viewData['CPU']->Price!=NULL)? $viewData['CPU']->Price."$": "unavailable"); ?></p>
						<form method="POST" action="<?php echo e(route('EditComputerHardware',$viewData['computer']->id)); ?>">
						<?php echo csrf_field(); ?>
						<input hidden value=1 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
							
						
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($viewData['CPU']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>

	<!-- 	Card2	 -->
	<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($viewData['Graphic']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($viewData['Graphic']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($viewData['Graphic']->Price!=NULL)? $viewData['Graphic']->Price."$": "unavailable"); ?></p>
						
						<form method="POST" action="<?php echo e(route('EditComputerHardware',$viewData['computer']->id)); ?>">
						<?php echo csrf_field(); ?>
						<input hidden value=2 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
				
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($viewData['Graphic']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
			<!-- 	Card3	 -->
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($viewData['Motherboard']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($viewData['Motherboard']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($viewData['Motherboard']->Price!=NULL)? $viewData['Motherboard']->Price."$": "unavailable"); ?></p>
						
						<form method="POST" action="<?php echo e(route('EditComputerHardware',$viewData['computer']->id)); ?>">
						<?php echo csrf_field(); ?>
						<input hidden value=3 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($viewData['Motherboard']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
			<!-- 	Card4	 -->
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($viewData['Power']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($viewData['Power']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($viewData['Power']->Price!=NULL)? $viewData['Power']->Price."$": "unavailable"); ?></p>
						
						<form method="POST" action="<?php echo e(route('EditComputerHardware',$viewData['computer']->id)); ?>">
						<?php echo csrf_field(); ?>
						<input hidden value=4 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($viewData['Power']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
			<!-- 	Card5	 -->
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($viewData['HardDisk']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($viewData['HardDisk']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($viewData['HardDisk']->Price!=NULL)? $viewData['HardDisk']->Price."$": "unavailable"); ?></p>
						
						<form method="POST" action="<?php echo e(route('EditComputerHardware',$viewData['computer']->id)); ?>">
						<?php echo csrf_field(); ?>
						<input hidden value=5 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($viewData['HardDisk']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
			<!-- 	Card6	 -->
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($viewData['Memory']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($viewData['Memory']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($viewData['Memory']->Price!=NULL)? $viewData['Memory']->Price."$": "unavailable"); ?></p>
						
						<form method="POST" action="<?php echo e(route('EditComputerHardware',$viewData['computer']->id)); ?>">
						<?php echo csrf_field(); ?>
						<input hidden value=6 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($viewData['Memory']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
      
       
	</div>
</div>




<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/editComputerPages/editComputer.blade.php ENDPATH**/ ?>