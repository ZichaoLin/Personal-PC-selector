
<?php echo $__env->make("layout.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection("title",$viewData['title']); ?>

<link rel="stylesheet" href=<?php echo e(URL('css/card.css')); ?> type="text/css">
<?php if(isset($viewData['CPUs'])): ?>
<h1 class="title cardTitle">Select your CPU</h1>

  
<section class="section">
	
	<div class="container">
		
    <?php $__currentLoopData = $viewData['CPUs']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CPU): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($CPU->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($CPU->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($CPU->Price!=NULL)? $CPU->Price."$": "unavailable"); ?></p>
						<form id="sendData" method="POST" action="display_policy">
     						<?php echo csrf_field(); ?>
     						 <input type="hidden" name="computerName" value="<?php echo e($viewData['computerName']); ?>">
	 						 <input type="hidden" name="computerDescription" value="<?php echo e($viewData['computerDescription']); ?>">
							<input type="hidden" name="CPUId" value="<?php echo e($CPU->CPU_ID); ?>">
							<button class="button is-info" >Add</button>
						</form>
					</div>
				</div>

				<div class="content">
					
					<a href="<?php echo e($CPU->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
       
	</div>
	</section>
	
	<?php else: ?>
		<article class="message is-danger">
  <div class="message-header">
    <p>Error</p>
    <button class="delete" aria-label="delete"></button>
  </div>
  <div class="message-body ">
  	No products found, please confirm whether the <strong>keywords</strong> are correct.
  </div>
</article>
	<?php endif; ?>		


<?php echo $__env->make("layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/BuildComputerPages/addComputer2.blade.php ENDPATH**/ ?>