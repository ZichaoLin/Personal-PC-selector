@extends('layout.header')
@include('layout.navbar')
<link rel="stylesheet" href={{URL('css/style.css')}} type="text/css">
<form class="box" method="POST" action="{{ route('register') }}">
    @csrf
    <h1>Register</h1>
    <input id="name" type="text" name="name" value="{{ old('name') }}" placeholder="Name" required autocomplete="name" autofocus>
    @error('name')
    <span>
        <strong class="error-message">{{ $message }}</strong>
    </span>
    @enderror
    <input id="email" type="email" name="email" placeholder="Email Address" value="{{ old('email') }}" required autocomplete="email" autofocus>
    @error('email')
    <span>
        <strong class="error-message">{{ $message }}</strong>
    </span>
    @enderror
    <input id="password" placeholder="Password" type="password" name="password" required autocomplete="current-password">
    @error('password')
    <span>
        <strong class="error-message">{{ $message }}</strong>
    </span>
    @enderror
    <input id="password-confirm" type="password" placeholder="Confirm Password" name="password_confirmation" required autocomplete="new-password">
    <input type="submit" name="" value="Register">

</form>
