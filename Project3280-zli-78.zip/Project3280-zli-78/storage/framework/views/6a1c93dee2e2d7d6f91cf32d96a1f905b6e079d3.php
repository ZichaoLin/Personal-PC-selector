    </div>
  </section>
  </body>
</html><?php /**PATH C:\Users\i\Desktop\project-3280\resources\views/layout/footer.blade.php ENDPATH**/ ?>