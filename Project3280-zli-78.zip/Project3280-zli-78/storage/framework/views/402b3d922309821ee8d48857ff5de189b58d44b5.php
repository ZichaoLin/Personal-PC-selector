
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title',$viewData['title']); ?>
<table class="table">
    <h1 class="title">Users Database</h1>
    <thead>
        <tr>
            <th><abbr title="id">id</abbr></th>
            <th>Name</th>
            <th>Email</th>
            <th>permission</th>
            <th>Create date</th>
            <th>Last Update</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th><abbr title="id">id</abbr></th>
            <th>Name</th>
            <th>Email</th>
            <th>permission</th>
            <th>Create date</th>
            <th>Last Update</th>
            <th></th>
            <th></th>
        </tr>
    </tfoot>
    <tbody>
        <?php $__currentLoopData = $viewData['Users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($user->id); ?></th>
            <td><?php echo e($user->name); ?>

            </td>
            <td><?php echo e($user->email); ?></td>
            <?php if($user->Admin): ?>
            <td>Admin</td>
            <?php else: ?>
            <td>User</td>
            <?php endif; ?>
            <th><?php echo e($user->created_at); ?></th>
            <th><?php echo e($user->updated_at); ?></th>
          
          
            <td>
                <a href="<?php echo e(route('UserEditPage',$user->id)); ?>" class="button is-info"> edit</a>


            </td>
            <td>
                <a href="<?php echo e(route('UserDelete',$user->id)); ?>" class="button is-danger">delete</a>


            </td>

            </td>
          
          
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\300304378\Desktop\Project3280-11-27\resources\views/adminLayout/userdatabase.blade.php ENDPATH**/ ?>