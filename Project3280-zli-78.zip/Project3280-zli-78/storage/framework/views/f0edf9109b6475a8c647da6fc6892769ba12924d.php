    </div>
  </section>
  </body>
  <footer class="footer">
  <div class="content has-text-centered">
    <p>
      <strong>Build</strong> by Zichao Lin. For CSIS-3280 final project
      
    </p>
  </div>
</footer>
</html><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/layout/footer.blade.php ENDPATH**/ ?>