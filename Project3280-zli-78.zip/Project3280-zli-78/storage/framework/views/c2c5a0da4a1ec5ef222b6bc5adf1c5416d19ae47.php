<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php if(auth()->guard()->guest()): ?>
<section class="hero is-info">
  <div class="hero-body">
    <p class="title">
    Welcome Guest
    </p>
    <p class="subtitle">
      Thank you for using this web page!
    </p>
  </div>
</section>
<?php else: ?>
<section class="hero is-info">
  <div class="hero-body">
    <p class="title">
    Hi <?php echo e(Auth::user()->name); ?> !
    </p>
    <p class="subtitle">
      Ready for a new computer?
    </p>
  </div>
</section>
<?php endif; ?>
<?php $__env->startSection('title',$viewData['title']); ?>



<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\300304378\Desktop\Project3280-11-27\resources\views/welcome.blade.php ENDPATH**/ ?>