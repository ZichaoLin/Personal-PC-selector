
<?php echo $__env->make("layout.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection("title",$viewData['title']); ?>

<link rel="stylesheet" href=<?php echo e(URL('css/card.css')); ?> type="text/css">

<section class="section">
	<div class="container">
		
    <?php $__currentLoopData = $viewData['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($product->product_main_image_url); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-4"><?php echo e($product->product_title); ?></p>
						<p class="subtitle is-6"><?php echo e($product->original_price); ?></p>
					</div>
				</div>

				<div class="content">
					
					<a href="<?php echo e($product->product_detail_url); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
	
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	
        
	</div>
	

</section>



<?php echo $__env->make("layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\300304378\Desktop\Project3280-11-27\resources\views/models/products.blade.php ENDPATH**/ ?>