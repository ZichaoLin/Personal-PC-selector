<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Computer;
use App\Models\Cpu;
use App\Models\Graphic;
use App\Models\Harddisk;
use App\Models\Memory;
use App\Models\Motherboard;
use App\Models\Power;
use App\Models\User;
use Illuminate\Routing\Route;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

use function PHPUnit\Framework\isNull;

class UserController extends Controller
{

  function userLogin()
  {
    $viewData = array();
    $viewData['title'] = "Login Page";
    $viewData['element'] = "";
    return view('auth.login')->with('viewData', $viewData);
  }

  function welcome()
  {
    $viewData = array();
    $viewData['title'] = "welcomePage";
    return view('welcome')->with('viewData', $viewData);
  }

  function Profilepage()
  {
    $viewData = array();
    $viewData['title'] = "Profile";
    //Check user login or not
    if (Auth::user()) {
      return view('models.editProfile')->with('viewData', $viewData);
    } else {
      return redirect()->route('welcome');
    }
  }
  //user edit
  function EditProfile(Request $postData)
  {
    $postData->validate([
      'name' => 'required',
      'email' => 'required|email|unique:users,email,' . Auth::user()->id . ',id',
      'new_password' => 'confirmed'

    ]);
    $user = User::findorFail(Auth::user()->id);
    $user->name = $postData->name;
    $user->email = $postData->email;
    if (isset($postData->new_password)) {
      $user->password = Hash::make($postData->new_password);
    }
    $user->save();
    return redirect()->route('welcome');
  }

  function products()
  {
    $viewData = array();
    $viewData['title'] = "Products";
    $curl = curl_init();
    $keyword = "CPU";
    curl_setopt_array($curl, [
    CURLOPT_URL => "https://amazon24.p.rapidapi.com/api/product?keyword=" . $keyword . "&country=US&page=1",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: amazon24.p.rapidapi.com",
        "X-RapidAPI-Key: 3639137b94msh650add17c6e547fp1e68bfjsne4781a7d9185"
      ],
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);
    $output = json_decode($response);

    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      foreach ($output->docs as $key => $value) {

        $viewData['products'][] = $value;

      }

    }
    return view('models.products')->with('viewData', $viewData);
  }

  function CompareComputer(){
    $viewData = array();
    $viewData['title'] = "CompareComputer";
    

    if (Auth::User()) {
      $viewData['computers'] = Computer::where('UserId',Auth::User()->id)->get();
      return view('models.compareComputers.compareComputers')->with("viewData", $viewData);
    }
    else{
      return redirect()->route('welcome');
    }


  }

  function Compare(Request $postData){
    $newData = array();
    if (Auth::User()) {
      $computer1 = Computer::find($postData->computer1);
      $computer2 = Computer::find($postData->computer2);
      //get info for computer1
              $newData['Name1'] = $computer1->Name;
              $newData['Description1'] = $computer1->Description;
              $newData['CPU1'] = CPU::FindOrFail($computer1->CPU_ID);
              $newData['Motherboard1'] = Motherboard::FindOrFail($computer1->MotherboardID);
              $newData['HardDisk1'] = Harddisk::FindOrFail($computer1->HardDiskID);
              $newData['Power1'] =  Power::FindOrFail($computer1->PowerID);
              $newData['Graphic1'] = Graphic:: FindOrFail($computer1->Graphics_cardID);
              $newData['Memory1'] = Memory:: FindOrFail($computer1->MemoryID);
            //get info for computer2  
              $newData['Name2'] = $computer2->Name;
              $newData['Description2'] = $computer2->Description;
              $newData['CPU2'] = CPU::FindOrFail($computer2->CPU_ID);
              $newData['Motherboard2'] = Motherboard::FindOrFail($computer2->MotherboardID);
              $newData['HardDisk2'] = Harddisk::FindOrFail($computer2->HardDiskID);
              $newData['Power2'] =  Power::FindOrFail($computer2->PowerID);
              $newData['Graphic2'] = Graphic:: FindOrFail($computer2->Graphics_cardID);
              $newData['Memory2'] = Memory:: FindOrFail($computer2->MemoryID);

      return $this->CompareComputer()->with("newData", $newData);
    }
    else{
      return redirect()->route('welcome');
    }


  }


}