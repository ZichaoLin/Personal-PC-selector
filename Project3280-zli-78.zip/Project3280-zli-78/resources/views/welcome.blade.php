@extends('layout.header')
@include('layout.navbar')


@guest
<section class="hero is-info">
  <div class="hero-body">
    <p class="title">
    Welcome Guest
    </p>
    <p class="subtitle">
      Thank you for using this web page!
    </p>
  </div>
</section>
@else
<section class="hero is-info">
  <div class="hero-body">
    <p class="title">
    Hi {{Auth::user()->name}} !
    </p>
    <p class="subtitle">
      Ready for a new computer?
    </p>
  </div>
</section>
@endguest
@section('title',$viewData['title'])
<div class="bulma-center-mixin-parent" style="padding-left:35%; padding-top:50px;">
<a  href="{{route('addComputerPage')}}">
<img class="bulma-center-mixin" height="500" width="500" class="image " src="{{URL('images/GetStarted.jpg')}}"  />
</a></div>
@extends('layout.footer')