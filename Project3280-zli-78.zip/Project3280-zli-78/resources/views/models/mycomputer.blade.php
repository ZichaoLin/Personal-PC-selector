@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])
<section class="section p-5">
    <div class="box">
<table class="table" >
    <h1 class="title has-text-centered">you have {{count($viewData['Computers'])}} computer(s)</h1>
    <thead>
        <tr>
           
            <th>Name</th>
            <th>Description</th>
            <th>Motherboard</th>
            <th>Power</th>
            <th>Graphics_card</th>
            <th>HardDisk</th>
            <th>CPU</th>
            <th>Memory</th>
            <th>Price</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Motherboard</th>
            <th>Power</th>
            <th>Graphics_card</th>
            <th>HardDisk</th>
            <th>CPU</th>
            <th>Memory</th>
            <th>Price</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </tfoot>
    <tbody>
        @if(isset($viewData['Computers']))
        @foreach($viewData['Computers'] as $comp)
        <tr>
           
            <td>{{$comp->Name}}</td>
           <td>{{$comp->Description}}</td>
            <td>{{$comp->motherboardName}}</td>
            <td>{{$comp->powerName}}</td>
            <td>{{$comp->graphicName}}</td>
            <td>{{$comp->harddiskName}}</td>
            
            <td>{{$comp->CPUName}}</td>
            <td>{{$comp->memoryName}}</td>
            <td>{{$comp->CPUPrice+
                $comp->GraphicsPrice+
                $comp->HardDiskPrice+
                $comp->MemoriePrice+
                $comp->MotherboardPrice+
                $comp->PowerPrice
            
            }}</td>
          
            <td>
                <a href="{{route('EditComputer',$comp->id)}}" class="button is-info"> Edit</a>


            </td>
            <td>
                <a href="{{route('DeleteComputer',$comp->id)}}" class="button is-danger">Delete</a>


            </td>

            </td>
          
          
        </tr>
        @endforeach
        @endif
    </tbody>
    </div>
</table>
</section>
@extends('layout.footer')