    </div>
  </section>
  </body>
</html><?php /**PATH C:\Users\300304378\Desktop\project-3280\resources\views/layout/footer.blade.php ENDPATH**/ ?>