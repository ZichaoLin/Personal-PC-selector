
<?php echo $__env->make("layout.navbar", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection("title",$viewData['title']); ?>
<section class="section">
  <h1 class="title has-text-centered">Add New Computer</h1>
<form class="box" action="<?php echo e(route('addHardware')); ?>" method="POST">
<?php echo csrf_field(); ?>
<div class="field">
  <label class="label" >Name</label>
  <div class="control">
    <input class="input" type="text" name="computerName" placeholder="Text input" required>
  </div>
</div>

<div class="field">
  <label class="label">Description</label>
  <div class="control">
    <textarea class="textarea" name="computerDescription" placeholder="Textarea"></textarea>
  </div>
</div>
<div class="field is-grouped">
  <div class="control">
    <button class="button is-link">
        Next
    </button>
  </div>
</div>
</form>
</section>

<?php echo $__env->make("layout.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make("layout.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/BuildComputerPages/addComputer.blade.php ENDPATH**/ ?>