<table class="table">


  <thead>
    <tr>
      <th><abbr title="Position">UserId</abbr></th>
      <th><abbr title="Played">Name</abbr></th>
      <th><abbr title="Won">Email</abbr></th>
      <th><abbr title="Drawn">Password</abbr></th>
    </tr>
  </thead>
  <tbody>

   <?php $__currentLoopData = $User; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

     <tr>  
      <td><?php echo e($person['User_Id']); ?></td>
      <td><?php echo e($person['Name']); ?></td>
      <td><?php echo e($person['Email']); ?></td>
      <td><?php echo e($person['Password']); ?></td>
        </tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table><?php /**PATH C:\Users\i\Desktop\project-3280\resources\views/models/user.blade.php ENDPATH**/ ?>