@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])


<link rel="stylesheet" href={{URL('css/card.css')}} type="text/css">
<section class="section box">
@if(isset($msg))
<article class="message is-primary">
  <div class="message-header">
    <p>Success</p>
    <a href="{{route('EditComputer',$viewData['computer']->id)}}" class="delete" aria-label="delete"></a>
  </div>
  <div class="message-body ">
  	{{$msg}}
  </div>
</article>
@else
@endif
<form action="{{route('EditComputerinfo',$viewData['computer']->id)}}" method="POST">
	@csrf
<div class="field">
  <label class="label" >Name</label>
  <div class="control">
    <input class="input" type="text" name="Name" value="{{$viewData['computer']->Name}}" placeholder="Text input">
  </div>
</div>
<div class="field">
  <label class="label">Description</label>
  <div class="control">
    <textarea class="textarea" name="Description"  placeholder="Textarea">{{$viewData['computer']->Description}}</textarea>
  </div>
</div>
<div class="field is-grouped">
  <div class="control">
    <button class="button is-link">
        Save
    </button>
  </div>
</div>
</form>
</section>
<div class="container">	
       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$viewData['CPU']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$viewData['CPU']->Name}}</p>
						<p class="subtitle is-6">{{($viewData['CPU']->Price!=NULL)? $viewData['CPU']->Price."$": "unavailable"}}</p>
						<form method="POST" action="{{route('EditComputerHardware',$viewData['computer']->id)}}">
						@csrf
						<input hidden value=1 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
							
						
					</div>
				</div>
				<div class="content">
					
					<a href="{{$viewData['CPU']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>

	<!-- 	Card2	 -->
	<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$viewData['Graphic']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$viewData['Graphic']->Name}}</p>
						<p class="subtitle is-6">{{($viewData['Graphic']->Price!=NULL)? $viewData['Graphic']->Price."$": "unavailable"}}</p>
						
						<form method="POST" action="{{route('EditComputerHardware',$viewData['computer']->id)}}">
						@csrf
						<input hidden value=2 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
				
					</div>
				</div>
				<div class="content">
					
					<a href="{{$viewData['Graphic']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
			<!-- 	Card3	 -->
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$viewData['Motherboard']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$viewData['Motherboard']->Name}}</p>
						<p class="subtitle is-6">{{($viewData['Motherboard']->Price!=NULL)? $viewData['Motherboard']->Price."$": "unavailable"}}</p>
						
						<form method="POST" action="{{route('EditComputerHardware',$viewData['computer']->id)}}">
						@csrf
						<input hidden value=3 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$viewData['Motherboard']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
			<!-- 	Card4	 -->
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$viewData['Power']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$viewData['Power']->Name}}</p>
						<p class="subtitle is-6">{{($viewData['Power']->Price!=NULL)? $viewData['Power']->Price."$": "unavailable"}}</p>
						
						<form method="POST" action="{{route('EditComputerHardware',$viewData['computer']->id)}}">
						@csrf
						<input hidden value=4 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$viewData['Power']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
			<!-- 	Card5	 -->
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$viewData['HardDisk']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$viewData['HardDisk']->Name}}</p>
						<p class="subtitle is-6">{{($viewData['HardDisk']->Price!=NULL)? $viewData['HardDisk']->Price."$": "unavailable"}}</p>
						
						<form method="POST" action="{{route('EditComputerHardware',$viewData['computer']->id)}}">
						@csrf
						<input hidden value=5 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$viewData['HardDisk']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
			<!-- 	Card6	 -->
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$viewData['Memory']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$viewData['Memory']->Name}}</p>
						<p class="subtitle is-6">{{($viewData['Memory']->Price!=NULL)? $viewData['Memory']->Price."$": "unavailable"}}</p>
						
						<form method="POST" action="{{route('EditComputerHardware',$viewData['computer']->id)}}">
						@csrf
						<input hidden value=6 name="Hardware">
						<button class="button is-info" >Edit</button>
						</form>
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$viewData['Memory']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
      
       
	</div>
</div>



@extends('layout.footer')