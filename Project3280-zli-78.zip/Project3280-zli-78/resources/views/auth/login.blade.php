@extends('layout.header')
@include('layout.navbar')
<link rel="stylesheet" href={{URL('css/style.css')}} type="text/css">
<form class="box" method="POST" action="{{ route('login') }}">
    @csrf
    <h1>Login</h1>
    <input id="email" type="email" name="email" placeholder="Email" value="{{ old('email') }}" required autocomplete="email" autofocus>

    <input id="password" placeholder="password" type="password" name="password" required autocomplete="current-password">
    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
    <label style="color:aliceblue" for="remember">
        {{ __('Remember Me') }}
    </label>
    <input type="submit" name="" value="Login">
    @error('email')
    <span>
        <strong class="error-message">{{ $message }}</strong>
    </span>
    @enderror
</form>
