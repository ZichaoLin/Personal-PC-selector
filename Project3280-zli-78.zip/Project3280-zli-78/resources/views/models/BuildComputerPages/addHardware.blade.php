@extends("layout.header")
@include("layout.navbar")
@section("title",$viewData['title'])

<link rel="stylesheet" href={{URL('css/card.css')}} type="text/css">
@if(isset($viewData['Products']))
<h1 class="title cardTitle">Select your {{$viewData['nextProduct']}}</h1>

  
<section class="section">
	
	<div class="container">
		
    @foreach($viewData['Products'] as $product)
	
       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$product->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$product->Name}}</p>
						<p class="subtitle is-6">{{($product->Price!=NULL)? $product->Price."$": "unavailable"}}</p>
						<form id="sendData" method="POST" action="{{route('addHardware')}}">
     						@csrf
     						 <input type="hidden" name="computerName" value="{{$postData['computerName']}}">
	 						 <input type="hidden" name="computerDescription" value="{{$postData['computerDescription']}}">
							<input type="hidden" name="lastProduct" value="{{$viewData['nextProduct']}}">
							   <input type="hidden" name="{{'ID'}}" value="{{$product->ID}}">
							<input type="hidden" name="CPUID" value="{{($postData['CPUID']!=null)? $postData['CPUID']: $viewData['CPUID']}}">
							<input type="hidden" name="MotherboardID" value="{{($postData['MotherboardID']!=null)? $postData['MotherboardID']: $viewData['MotherboardID']}}">
							<input type="hidden" name="Graphics_CardID" value="{{($postData['Graphics_CardID']!=null)? $postData['Graphics_CardID']: $viewData['Graphics_CardID']}}">
							<input type="hidden" name="Power_SupplyID" value="{{($postData['Power_SupplyID']!=null)? $postData['Power_SupplyID']: $viewData['Power_SupplyID']}}">
							<input type="hidden" name="Hard_DiskID" value="{{($postData['Hard_DiskID']!=null)? $postData['Hard_DiskID']: $viewData['Hard_DiskID']}}"> 
							
							@if($product->Price!=NULL)
							<button class="button is-info" >Add</button>
                            @else
                            @endif
						</form>
					</div>
				</div>

				<div class="content">
					
					<a href="{{$product->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>


        @endforeach	
       
	</div>
	</section>
	
	@else
		<article class="message is-danger">
  <div class="message-header">
    <p>Error</p>
    <button class="delete" aria-label="delete"></button>
  </div>
  <div class="message-body ">
  	No products found, please confirm whether the <strong>keywords</strong> are correct.
  </div>
</article>
	@endif		

@extends("layout.footer")