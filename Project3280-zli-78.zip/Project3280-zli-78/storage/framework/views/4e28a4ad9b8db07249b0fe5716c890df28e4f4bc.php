
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title',$viewData['title']); ?>
<?php if(count($viewData['computers'])>=2): ?>
<section class="section">
<form class="box has-text-centered" method="POST" action="" >
    <p class="title">Select your computers to compare!</p>
<?php echo csrf_field(); ?>
<div class="select is-rounded">
<select name="computer1" >
<?php $__currentLoopData = $viewData['computers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $computer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($computer->id); ?>"><?php echo e($computer->Name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<div class="select is-rounded">
<select name="computer2" >
<?php $__currentLoopData = $viewData['computers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $computer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<option value="<?php echo e($computer->id); ?>"><?php echo e($computer->Name); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>
<br>
<button class="button is-warning m-5">Compare</button>
</form>
</section>
<?php else: ?>
<article class="message is-danger">
  <div class="message-header">
    <p>Error</p>
  </div>
  <div class="message-body ">
  	You don't have enough computers to compare! <a href="<?php echo e(route('addComputerPage')); ?>"><strong>Go Create One</strong></a>
  </div>
</article>
<?php endif; ?>

<?php if(isset($newData)): ?>
<link rel="stylesheet" href=<?php echo e(URL('css/card.css')); ?> type="text/css">
<section class="section">
<table class="table m-auto box">
<thead>
    <tr>
        <th><?php echo e($newData['Name1']); ?></th>
        <th><?php echo e($newData['Name2']); ?></th>
        
    </tr>

   
</thead>
<tfoot>
    <tr>
        <th><?php echo e($newData['Name1']); ?></th>
        <th><?php echo e($newData['Name2']); ?></th>
        
    </tr>

   
</tfoot>
<tbody>
       
        <tr class="tableCard">
            	<!-- 	Card	 -->
            <th>
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['CPU1']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['CPU1']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['CPU1']->Price!=NULL)? $newData['CPU1']->Price."$": "unavailable"); ?></p>
						
							
						
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['CPU1']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
        </th>
    
        <!-- 	Card	 -->
        <th>
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['CPU2']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['CPU2']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['CPU2']->Price!=NULL)? $newData['CPU2']->Price."$": "unavailable"); ?></p>
						
							
						
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['CPU2']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
        </th>
        </tr>

    <tr class="tableCard"> 
    	<!-- 	Card2	 -->    
    <th>
	<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['Graphic1']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['Graphic1']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['Graphic1']->Price!=NULL)? $newData['Graphic1']->Price."$": "unavailable"); ?></p>
						
						
				
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['Graphic1']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
    </th>
    <!-- 	Card2	 -->    
    <th>
	<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['Graphic2']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['Graphic2']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['Graphic2']->Price!=NULL)? $newData['Graphic2']->Price."$": "unavailable"); ?></p>
						
						
				
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['Graphic2']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>
    </th>
        </tr>
			
            <tr class="tableCard">
            <!-- 	Card3	 -->    
            <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['Motherboard1']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['Motherboard1']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['Motherboard1']->Price!=NULL)? $newData['Motherboard1']->Price."$": "unavailable"); ?></p>
						
					
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['Motherboard1']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div></th>

        <!-- 	Card3	 -->    
        <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['Motherboard2']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['Motherboard2']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['Motherboard2']->Price!=NULL)? $newData['Motherboard2']->Price."$": "unavailable"); ?></p>
						
					
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['Motherboard2']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div></th>
            </tr >
		
            <tr class="tableCard">
                	<!-- 	Card4	 -->
            <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['Power1']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['Power1']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['Power1']->Price!=NULL)? $newData['Power1']->Price."$": "unavailable"); ?></p>
						
						
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['Power1']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div></th>

        <!-- 	Card4	 -->
        <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['Power2']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['Power2']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['Power2']->Price!=NULL)? $newData['Power2']->Price."$": "unavailable"); ?></p>
						
						
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['Power2']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div></th>
        </tr >
		
            <tr class="tableCard">
            	<!-- 	Card5	 -->    
            <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['HardDisk1']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['HardDisk1']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['HardDisk1']->Price!=NULL)? $newData['HardDisk1']->Price."$": "unavailable"); ?></p>
						
						
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['HardDisk1']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div></th>
        <!-- 	Card5	 -->    
        <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['HardDisk2']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['HardDisk2']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['HardDisk2']->Price!=NULL)? $newData['HardDisk2']->Price."$": "unavailable"); ?></p>
						
						
					
					</div>
				</div>
				<div class="content">
					
					<a href="<?php echo e($newData['HardDisk2']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div></th>
        </tr>
	
            <tr class="tableCard">
            		<!-- 	Card6	 -->    
            <th>
		<div class="card">
			            <div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['Memory1']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			            </div>
		        <div class="card-content">
				    <div class="media">
	
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['Memory1']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['Memory1']->Price!=NULL)? $newData['Memory1']->Price."$": "unavailable"); ?></p>
                    </div>
				    </div>
				<div class="content">
					
					<a href="<?php echo e($newData['Memory1']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div></th>
        <!-- 	Card6	 -->    
        <th>
		<div class="card">
			            <div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($newData['Memory2']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			            </div>
		        <div class="card-content">
				    <div class="media">
	
					<div class="media-content">
						<p class="title is-5"><?php echo e($newData['Memory2']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($newData['Memory2']->Price!=NULL)? $newData['Memory2']->Price."$": "unavailable"); ?></p>
                    </div>
				    </div>
				<div class="content">
					
					<a href="<?php echo e($newData['Memory2']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div></th>
        </tr>
       <tr>
        <th> total: <?php echo e($newData['Memory1']->Price+$newData['CPU1']->Price+$newData['HardDisk1']->Price+$newData['Motherboard1']->Price+$newData['Graphic1']->Price+$newData['Power1']->Price); ?></th>
        <th> total: <?php echo e($newData['Memory2']->Price+$newData['CPU2']->Price+$newData['HardDisk2']->Price+$newData['Motherboard2']->Price+$newData['Graphic2']->Price+$newData['Power2']->Price); ?></th>
       </tr>
	<!-- </div> -->

</tbody>

</table>
</section>
<?php else: ?>
<?php endif; ?>




<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/compareComputers/compareComputers.blade.php ENDPATH**/ ?>