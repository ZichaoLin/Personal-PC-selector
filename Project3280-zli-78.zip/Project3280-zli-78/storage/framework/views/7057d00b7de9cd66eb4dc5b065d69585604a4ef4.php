<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php if(auth()->guard()->guest()): ?>
<section class="hero is-info">
  <div class="hero-body">
    <p class="title">
    Welcome Guest
    </p>
    <p class="subtitle">
      Thank you for using this web page!
    </p>
  </div>
</section>
<?php else: ?>
<section class="hero is-info">
  <div class="hero-body">
    <p class="title">
    Hi <?php echo e(Auth::user()->name); ?> !
    </p>
    <p class="subtitle">
      Ready for a new computer?
    </p>
  </div>
</section>
<?php endif; ?>
<?php $__env->startSection('title',$viewData['title']); ?>
<div class="bulma-center-mixin-parent" style="padding-left:35%; padding-top:50px;">
<a  href="<?php echo e(route('addComputerPage')); ?>">
<img class="bulma-center-mixin" height="500" width="500" class="image " src="<?php echo e(URL('images/GetStarted.jpg')); ?>"  />
</a></div>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/welcome.blade.php ENDPATH**/ ?>