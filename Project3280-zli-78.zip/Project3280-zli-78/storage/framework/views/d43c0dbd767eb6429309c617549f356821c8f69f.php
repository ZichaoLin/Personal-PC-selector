
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href=<?php echo e(URL('css/style.css')); ?> type="text/css">
<?php $__env->stopPush(); ?>
<form class="box" method="POST" action="<?php echo e(route('Login')); ?>">
    <?php echo csrf_field(); ?>
    <h1>Login</h1>
    <input type="text" name="Name" placeholder="Username">
    <input type="password" name="Password" placeholder="password">
    <input type="submit" name="" value="Login">
    <p><?php echo e($viewData['element']); ?></p>
</form>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\project-3280\resources\views/login.blade.php ENDPATH**/ ?>