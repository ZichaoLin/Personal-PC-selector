<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Computer;
use App\Models\Cpu;
use App\Models\Graphic;
use App\Models\Harddisk;
use App\Models\Memory;
use App\Models\Motherboard;
use App\Models\Power;
use App\Models\User;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use function PHPUnit\Framework\isNull;

class ComputerController extends Controller
{
    function addComputerPage(){
        $viewData = array();
        $viewData['title']  = "Build Computer";
    
        return view('models.BuildComputerPages.addComputer')->with('viewData', $viewData);
      }
      function addHardware(Request $postData){
        $viewData = array();
        $viewData['title']  = "Choose Hardware";
        $viewData["CPUID"] = isset($postData["CPUID"]) ? $postData["CPUID"] : null;
        $viewData["MotherboardID"] = isset($postData["MotherboardID"]) ? $postData["MotherboardID"] : null;
        
        $viewData["Graphics_CardID"] = isset($postData["Graphics_CardID"]) ? $postData["Graphics_CardID"] : null;
        $viewData["Power_SupplyID"]= isset($postData["Power_SupplyID"]) ? $postData["Power_SupplyID"] : null;
        $viewData["Hard_DiskID"]= isset($postData["Hard_DiskID"]) ? $postData["Hard_DiskID"] : null;
    
        if(isset($postData["lastProduct"])){
         
        switch($postData["lastProduct"]){
            case 'CPU':
              $viewData['nextProduct'] = "Motherboard";
              $viewData['Products'] = Motherboard::all();
              $className = "App\Models\Motherboard";
              $viewData["CPUID"] = $postData['ID'];
              break;
            case 'Motherboard':
              $viewData['Products'] = Graphic::all();
              $viewData['nextProduct'] = "Graphics Card";
              $className = "App\Models\Graphic";
              $viewData["MotherboardID"] = $postData['ID'];
              break;
              case 'Graphics Card':
                $viewData['Products'] = Power::all();
                $viewData['nextProduct'] = "Power Supply";
                $className = "App\Models\Power";
                $viewData["Graphics_CardID"] = $postData['ID'];
                break; 
                case 'Power Supply':
                  $viewData['Products'] = Harddisk::all();
                  $viewData['nextProduct'] = "Hard Disk";
                  $className = "App\Models\Harddisk";
                  $viewData["Power_SupplyID"] = $postData['ID'];
                  break;
                  case 'Hard Disk':
                    $viewData['Products'] = Memory::all();
                    $viewData['nextProduct'] = "Desktop Memory";
                    $className = "App\Models\Memory";
                    $viewData["Hard_DiskID"] = $postData['ID'];
                    break;
            case 'Desktop Memory':
              if (Auth::user()) {
                $computer = new Computer();
                $computer->UserID = Auth::user()->id;
                $computer->Name = $postData['computerName'];
                $computer->Description = $postData['computerDescription'];
                $computer->MotherboardID = $postData['MotherboardID'];
                $computer->PowerID  = $postData['Power_SupplyID'];
                $computer->Graphics_cardID= $postData['Graphics_CardID'];
                $computer->HardDiskID= $postData['Hard_DiskID'];
                $computer->CPU_ID= $postData['CPUID'];
                $computer->MemoryID= $postData['ID'];
                $computer->save();
                return redirect()->route('ViewComputers');
    
              }else {
                return redirect()->route('welcome');
              }
                     
        }
      }else {
        $viewData['nextProduct'] = "CPU";
        $viewData['Products'] = CPU::all();
          $className = "App\Models\CPU";
      }
     
        if (isset($viewData['Products'][0])) {
           return view('models.BuildComputerPages.addHardware')->with('viewData', $viewData)->with('postData',$postData);
        }
        else{
          
          $data = $this->getapi($viewData['nextProduct']);
          foreach ($data as  $item) {
            $newData = new $className;
            $newData->ID = $item->product_id;
            $newData->Name = $item->product_title;
            $newData->ImageURL= addslashes($item->product_main_image_url);
            $newData->URL = addslashes($item->product_detail_url);
            $newData->Price = ($item->app_sale_price != NULL) ? str_replace(",", "", $item->app_sale_price) : NULL;
            $newData -> save();
            
            
          }
          $viewData['Products'] = $className::all();
          
        }
         return view('models.BuildComputerPages.addHardware')->with('viewData', $viewData)->with('postData',$postData);
      }
      function ViewComputers(){
        $viewData = array();
        $viewData['title'] = "View Computers";

        if (Auth::user()) {
            $table=  DB::table('computers')
            ->select(
                'computers.id',
            'computers.Name',
            'computers.UserId',
            'computers.Description',
            //name
            'CPUs.Name as CPUName',
            'graphics.Name as graphicName',
            'harddisks.Name as harddiskName',
            'memories.Name as memoryName',
            'motherboards.Name as motherboardName',
            'powers.Name as powerName',
            //price
            'CPUs.price as CPUPrice',
            "graphics.price as GraphicsPrice",
            "harddisks.price as HardDiskPrice",
            "memories.price as MemoriePrice",
            "motherboards.price as MotherboardPrice",
            "powers.price as PowerPrice")
            ->join('CPUs','CPUs.ID','=','computers.CPU_ID')
            ->join('graphics','graphics.ID','=','computers.Graphics_cardID')
            ->join('harddisks','harddisks.ID','=','computers.HardDiskID')
            ->join('memories','memories.ID','=','computers.MemoryID')
            ->join('motherboards','motherboards.ID','=','computers.motherboardID')
            ->join('powers','powers.ID','=','computers.powerID')
            ->where('computers.UserId',"=", Auth::user()->id)
            ->get();
                   
            $viewData['Computers'] = $table;
            return view('models.mycomputer')->with('viewData', $viewData);
        }
        else{
            return redirect()->route('welcome');
        }
    
        
      }

      function DeleteComputer ($id){
        if (Auth::User()) { //Check login
            $owner = Computer::FindOrFail($id)->UserId;
             if($owner==Auth::User()->id||Auth::user()->Admin){//Check Owner match this user
                Computer::destroy($id);
                return redirect()->route('ViewComputers');
             } else {
                return redirect()->route('welcome');
             }
             
             
        }
        return redirect()->route('welcome');
      }
      function EditComputer ($id){
        $viewData = array();
        $viewData['title'] = "EditComputer";
        
        if (Auth::User()) { //Check login
          
            $owner = Computer::FindOrFail($id)->UserId;
             if($owner==Auth::user()->id||Auth::user()->Admin){//Check Owner match this user or admin
              
              $computer =  Computer::FindOrFail($id);
             $viewData['computer'] = $computer;
              $viewData['Name'] = $computer->Name;
       
              $viewData['Description'] = $computer->Description;

              $viewData['CPU'] = CPU::FindOrFail($computer->CPU_ID);
              $viewData['Motherboard'] = Motherboard::FindOrFail($computer->MotherboardID);
              $viewData['HardDisk'] = Harddisk::FindOrFail($computer->HardDiskID);
              $viewData['Power'] =  Power::FindOrFail($computer->PowerID);
             
              $viewData['Graphic'] = Graphic:: FindOrFail($computer->Graphics_cardID);
              $viewData['Memory'] = Memory:: FindOrFail($computer->MemoryID);
     
               return view("models.editComputerPages.editComputer")->with("viewData", $viewData);
             } else {
                return redirect()->route('welcome');
             }
             

        }
        return redirect()->route('welcome');
      }

  function EditComputerinfo(Request $postData,$id){
    if (Auth::User()) { //Check login

      $owner = Computer::FindOrFail($id)->UserId;
      if ($owner == Auth::User()->id||Auth::user()->Admin) { //Check Owner match this user
       
      $computer=  Computer::FindOrFail($id);
      $computer->Name = $postData->Name;
      $computer->Description = $postData->Description;
      $computer->save();
      return redirect()->route('ViewComputers');
    }else {
      return redirect()->route('welcome');
   }
   }
   return redirect()->route('welcome');
  }
  function EditComputerHardware(Request $postData,$id){
   $viewData = array();
    $viewData['title'] = "Edit Hardware";
    if (Auth::User()) { //Check login
      
      $owner = Computer::FindOrFail($id)->UserId;
      if ($owner == Auth::User()->id||Auth::user()->Admin) { //Check Owner match this user
       
     switch($postData['Hardware']){
          case "1":
            $viewData['Hardware'] = "CPU";
            $viewData['Products'] = CPU::all();
            break;
      case "2":
        $viewData['Hardware'] = "Garphic";
            $viewData['Products'] = Graphic::all();
            break;
      case "3":
        $viewData['Hardware'] = "Motherboard";
            $viewData['Products'] = Motherboard::all();
            break;
      case "4":
        $viewData['Hardware'] = "Power";
            $viewData['Products'] = Power::all();
            break;
      case "5":
        $viewData['Hardware'] = "HardDisk";
            $viewData['Products'] = HardDisk::all();
            break;
      case "6":
        $viewData['Hardware'] = "Memory";
            $viewData['Products'] = Memory::all();
            break;

     }
    
      return view("models.editComputerPages.editHardware")->with("viewData",$viewData)->with("id",$id);
    }else {
      return redirect()->route('welcome');
   }
   }
   return redirect()->route('welcome');
  }

  function ChangeHardware(Request $postData){
   
    if (Auth::User()) { //Check login
      $computer = Computer::FindOrFail($postData->computerId);
      $owner = $computer->UserId;
     
      if ($owner == Auth::User()->id||Auth::user()->Admin) { //Check Owner match this user
        
        switch ($postData['Hardware']) {
          case 'CPU':
            $computer->CPU_ID = $postData->ID;
            break;
          case 'Garphic':
            $computer->Graphics_cardID = $postData->ID;
            break;
          case 'Motherboard':
            $computer->MotherboardID = $postData->ID;
            break;
          case 'Power':
            $computer->PowerID = $postData->ID;
            break;
          case 'HardDisk':
            $computer->HardDiskID = $postData->ID;
            break;
          case 'Memory':
            $computer->MemoryID = $postData->ID;
            break;
        }
      
        $computer->save();
        $msg = "Updata Success";
       return $this->EditComputer($postData->computerId)->with('msg', $msg);
      
      
      
      } else {
         return redirect()->route('welcome');
      }
     
    }
    return redirect()->route('welcome');
  }

  
      function getapi($keyword){//function to getdata from api
        $curl = curl_init();
        curl_setopt_array($curl, [
          CURLOPT_URL => "https://amazon24.p.rapidapi.com/api/product?keyword=". $keyword."&country=US&page=1",
          CURLOPT_RETURNTRANSFER => true,
          CURLOPT_FOLLOWLOCATION => true,
          CURLOPT_ENCODING => "",
          CURLOPT_MAXREDIRS => 10,
          CURLOPT_TIMEOUT => 30,
          CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
          CURLOPT_CUSTOMREQUEST => "GET",
          CURLOPT_HTTPHEADER => [
            "X-RapidAPI-Host: amazon24.p.rapidapi.com",
            "X-RapidAPI-Key: 3639137b94msh650add17c6e547fp1e68bfjsne4781a7d9185"
          ],
        ]);
    
        $response = curl_exec($curl);
        $err = curl_error($curl);
    
        curl_close($curl);
        $output = json_decode($response);
        $data = array();
        if ($err) {
          echo "cURL Error #:" . $err;
        } else {
          foreach ($output->docs as $key => $value) {
    
            $data[] = $value;
         
          }
         
        }
        return $data;
      }


    
 }

