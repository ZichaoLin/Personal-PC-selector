@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])
@if(count($viewData['computers'])>=2)
<section class="section">
<form class="box has-text-centered" method="POST" action="" >
    <p class="title">Select your computers to compare!</p>
@csrf
<div class="select is-rounded">
<select name="computer1" >
@foreach($viewData['computers'] as $computer)
<option value="{{$computer->id}}">{{$computer->Name}}</option>
@endforeach
</select>
</div>
<div class="select is-rounded">
<select name="computer2" >
@foreach($viewData['computers'] as $computer)
<option value="{{$computer->id}}">{{$computer->Name}}</option>
@endforeach
</select>
</div>
<br>
<button class="button is-warning m-5">Compare</button>
</form>
</section>
@else
<article class="message is-danger">
  <div class="message-header">
    <p>Error</p>
  </div>
  <div class="message-body ">
  	You don't have enough computers to compare! <a href="{{route('addComputerPage')}}"><strong>Go Create One</strong></a>
  </div>
</article>
@endif

@if(isset($newData))
<link rel="stylesheet" href={{URL('css/card.css')}} type="text/css">
<section class="section">
<table class="table m-auto box">
<thead>
    <tr>
        <th>{{$newData['Name1']}}</th>
        <th>{{$newData['Name2']}}</th>
        
    </tr>

   
</thead>
<tfoot>
    <tr>
        <th>{{$newData['Name1']}}</th>
        <th>{{$newData['Name2']}}</th>
        
    </tr>

   
</tfoot>
<tbody>
       
        <tr class="tableCard">
            	<!-- 	Card	 -->
            <th>
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['CPU1']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['CPU1']->Name}}</p>
						<p class="subtitle is-6">{{($newData['CPU1']->Price!=NULL)? $newData['CPU1']->Price."$": "unavailable"}}</p>
						
							
						
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['CPU1']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
        </th>
    
        <!-- 	Card	 -->
        <th>
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['CPU2']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['CPU2']->Name}}</p>
						<p class="subtitle is-6">{{($newData['CPU2']->Price!=NULL)? $newData['CPU2']->Price."$": "unavailable"}}</p>
						
							
						
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['CPU2']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
        </th>
        </tr>

    <tr class="tableCard"> 
    	<!-- 	Card2	 -->    
    <th>
	<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['Graphic1']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['Graphic1']->Name}}</p>
						<p class="subtitle is-6">{{($newData['Graphic1']->Price!=NULL)? $newData['Graphic1']->Price."$": "unavailable"}}</p>
						
						
				
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['Graphic1']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
    </th>
    <!-- 	Card2	 -->    
    <th>
	<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['Graphic2']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['Graphic2']->Name}}</p>
						<p class="subtitle is-6">{{($newData['Graphic2']->Price!=NULL)? $newData['Graphic2']->Price."$": "unavailable"}}</p>
						
						
				
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['Graphic2']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>
    </th>
        </tr>
			
            <tr class="tableCard">
            <!-- 	Card3	 -->    
            <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['Motherboard1']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['Motherboard1']->Name}}</p>
						<p class="subtitle is-6">{{($newData['Motherboard1']->Price!=NULL)? $newData['Motherboard1']->Price."$": "unavailable"}}</p>
						
					
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['Motherboard1']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div></th>

        <!-- 	Card3	 -->    
        <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['Motherboard2']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['Motherboard2']->Name}}</p>
						<p class="subtitle is-6">{{($newData['Motherboard2']->Price!=NULL)? $newData['Motherboard2']->Price."$": "unavailable"}}</p>
						
					
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['Motherboard2']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div></th>
            </tr >
		
            <tr class="tableCard">
                	<!-- 	Card4	 -->
            <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['Power1']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['Power1']->Name}}</p>
						<p class="subtitle is-6">{{($newData['Power1']->Price!=NULL)? $newData['Power1']->Price."$": "unavailable"}}</p>
						
						
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['Power1']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div></th>

        <!-- 	Card4	 -->
        <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['Power2']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['Power2']->Name}}</p>
						<p class="subtitle is-6">{{($newData['Power2']->Price!=NULL)? $newData['Power2']->Price."$": "unavailable"}}</p>
						
						
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['Power2']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div></th>
        </tr >
		
            <tr class="tableCard">
            	<!-- 	Card5	 -->    
            <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['HardDisk1']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['HardDisk1']->Name}}</p>
						<p class="subtitle is-6">{{($newData['HardDisk1']->Price!=NULL)? $newData['HardDisk1']->Price."$": "unavailable"}}</p>
						
						
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['HardDisk1']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div></th>
        <!-- 	Card5	 -->    
        <th>
			<div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['HardDisk2']->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$newData['HardDisk2']->Name}}</p>
						<p class="subtitle is-6">{{($newData['HardDisk2']->Price!=NULL)? $newData['HardDisk2']->Price."$": "unavailable"}}</p>
						
						
					
					</div>
				</div>
				<div class="content">
					
					<a href="{{$newData['HardDisk2']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div></th>
        </tr>
	
            <tr class="tableCard">
            		<!-- 	Card6	 -->    
            <th>
		<div class="card">
			            <div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['Memory1']->ImageURL}}" alt="Placeholder image">
				</figure>
			            </div>
		        <div class="card-content">
				    <div class="media">
	
					<div class="media-content">
						<p class="title is-5">{{$newData['Memory1']->Name}}</p>
						<p class="subtitle is-6">{{($newData['Memory1']->Price!=NULL)? $newData['Memory1']->Price."$": "unavailable"}}</p>
                    </div>
				    </div>
				<div class="content">
					
					<a href="{{$newData['Memory1']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div></th>
        <!-- 	Card6	 -->    
        <th>
		<div class="card">
			            <div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$newData['Memory2']->ImageURL}}" alt="Placeholder image">
				</figure>
			            </div>
		        <div class="card-content">
				    <div class="media">
	
					<div class="media-content">
						<p class="title is-5">{{$newData['Memory2']->Name}}</p>
						<p class="subtitle is-6">{{($newData['Memory2']->Price!=NULL)? $newData['Memory2']->Price."$": "unavailable"}}</p>
                    </div>
				    </div>
				<div class="content">
					
					<a href="{{$newData['Memory2']->URL}}">View Product Page</a>	
				</div>
			</div>
		</div></th>
        </tr>
       <tr>
        <th> total: {{$newData['Memory1']->Price+$newData['CPU1']->Price+$newData['HardDisk1']->Price+$newData['Motherboard1']->Price+$newData['Graphic1']->Price+$newData['Power1']->Price}}</th>
        <th> total: {{$newData['Memory2']->Price+$newData['CPU2']->Price+$newData['HardDisk2']->Price+$newData['Motherboard2']->Price+$newData['Graphic2']->Price+$newData['Power2']->Price}}</th>
       </tr>
	<!-- </div> -->

</tbody>

</table>
</section>
@else
@endif



@extends('layout.footer')