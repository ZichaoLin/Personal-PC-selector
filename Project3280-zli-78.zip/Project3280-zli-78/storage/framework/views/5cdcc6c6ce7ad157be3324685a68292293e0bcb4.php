    </div>
  </section>
  </body>
  <!-- <footer class="footer">
  <div >
    <p>
      <strong>Bulma</strong> by <a href="https://jgthms.com">Jeremy Thomas</a>. The source code is licensed
      <a href="http://opensource.org/licenses/mit-license.php">MIT</a>. The website content
      is licensed <a href="http://creativecommons.org/licenses/by-nc-sa/4.0/">CC BY NC SA 4.0</a>.
    </p>
  </div>
</footer> -->
</html><?php /**PATH C:\Users\300304378\Desktop\Project3280-11-27\resources\views/layout/footer.blade.php ENDPATH**/ ?>