
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title',$viewData['title']); ?>
<table class="table">
    <h1 class="title">Computer Database</h1>
    <thead>
        <tr>
            <th>Computer_ID</th>
            <th>UserId</th>
            <th>Name</th>
            <th>MotherboardID</th>
            <th>PowerID</th>
            <th>Graphics_cardID</th>
            <th>HardDiskID</th>
            <th>CPU_ID</th>
            <th>MemoryID</th>
            <th>Price</th>

        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>Computer_ID</th>
            <th>UserId</th>
            <th>Name</th>
            <th>MotherboardID</th>
            <th>PowerID</th>
            <th>Graphics_cardID</th>
            <th>HardDiskID</th>
            <th>CPU_ID</th>
            <th>MemoryID</th>
            <th>Price</th>

        </tr>
    </tfoot>
    <tbody>
        <?php if(isset($viewData['Computers'])): ?>
        <?php $__currentLoopData = $viewData['Users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($user->id); ?></th>
            <td><?php echo e($user->name); ?>

            </td>
            <td><?php echo e($user->email); ?></td>
            <?php if($user->Admin): ?>
            <td>Admin</td>
            <?php else: ?>
            <td>User</td>
            <?php endif; ?>
            <th><?php echo e($user->created_at); ?></th>
            <th><?php echo e($user->updated_at); ?></th>
          
          
            <td>
                <a href="<?php echo e(route('UserEditPage',$user->id)); ?>" class="button is-info"> edit</a>


            </td>
            <td>
                <a href="<?php echo e(route('UserDelete',$user->id)); ?>" class="button is-danger">delete</a>


            </td>

            </td>
          
          
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\project-3280\resources\views/adminLayout/computerDatabase.blade.php ENDPATH**/ ?>