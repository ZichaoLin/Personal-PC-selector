<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Computer;
use App\Models\Cpu;
use App\Models\Graphic;
use App\Models\HardDisk;
use App\Models\Memory;
use App\Models\Motherboard;
use App\Models\Power;
use App\Models\User;
use Illuminate\Routing\Route;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
class AdminController extends Controller
{

    function Userdatabase()
    {
      $viewData = array();
      $viewData['title']  = "User Database";
      $Users = User::all();
      $viewData['Users'] = $Users;
      //Check user is admin or not
      if (Auth::user() && Auth::user()->Admin) {
        return view('models.adminLayout.userdatabase')->with('viewData', $viewData);
      } else {
        return redirect()->route('welcome');
      }
    }

    function UserEditPage($id)
  {
    $viewData = array();
    $viewData['title']  = "EditUser";
    $user = User::findOrFail($id);
    $viewData['user']= $user;

    //Check user is admin or not
   if (Auth::user() && Auth::user()->Admin) {
    return view(' models.adminLayout.editUser')->with('viewData', $viewData);
  } else {
    return redirect()->route('welcome');
  }
  }


  function Userdelete($id)
  {
    //check
    if (Auth::user() && Auth::user()->Admin) {
      User::destroy($id);
    return back();
    } else {
      return redirect()->route('welcome');
    }
   
  }

  function UserEdit(Request $postData,$id){
    $postData->validate([
      'name' => 'required',
      'email' => 'required|email|unique:users,email,' . $id . ',id',
      'new_password' => 'confirmed'

    ]);
    $user = User::findorFail($id);
    $user->name = $postData->name;
    $user->email = $postData->email;
    if (isset($postData->new_password)) {
      $user->password = Hash::make($postData->new_password);
    }
    $user->Admin = isset($postData->Admin);
    $user->save();
    return redirect()->route('Userdatabase');
  }

  function ComputerDatabase()
  {
    $viewData = array();
    $viewData['title']  = "Computers Database";
    

    //Check user is admin or not
    if (Auth::user() && Auth::user()->Admin) {
      $table=  DB::table('computers')
            ->select(
              'Users.Name as UserName',
                'computers.id',
            'computers.Name',
            'computers.UserId',
            'computers.Description',
            //name
            'CPUs.Name as CPUName',
            'graphics.Name as graphicName',
            'harddisks.Name as harddiskName',
            'memories.Name as memoryName',
            'motherboards.Name as motherboardName',
            'powers.Name as powerName',
            //price
            'CPUs.price as CPUPrice',
            "graphics.price as GraphicsPrice",
            "harddisks.price as HardDiskPrice",
            "memories.price as MemoriePrice",
            "motherboards.price as MotherboardPrice",
            "powers.price as PowerPrice")
            ->join('Users','Users.id','=','computers.UserId')
            ->join('CPUs','CPUs.ID','=','computers.CPU_ID')
            ->join('graphics','graphics.ID','=','computers.Graphics_cardID')
            ->join('harddisks','harddisks.ID','=','computers.HardDiskID')
            ->join('memories','memories.ID','=','computers.MemoryID')
            ->join('motherboards','motherboards.ID','=','computers.motherboardID')
            ->join('powers','powers.ID','=','computers.powerID')
            ->get();
                   
            $viewData['Computers'] = $table;
      return view('models.adminLayout.computerDatabase')->with('viewData', $viewData);
    } else {
      return redirect()->route('welcome');
    }
   
  }

  function CreateUserPage(){
    $viewData = array();
    $viewData['title']  = "Create User";
    

    //Check user is admin or not
    if (Auth::user() && Auth::user()->Admin) {
      return view('models.adminLayout.createAccount')->with('viewData', $viewData);
    } else {
      return redirect()->route('welcome');
    }
  }

  function HardwareDatabase($hardware){
    $viewData = array();
    $viewData['title']  = "Hardwares Database";
    $viewData['productsName'] = $hardware;
    //Check user is admin or not
   if (Auth::user() && Auth::user()->Admin) {
      switch ($hardware) {
        case 'CPU':
          $viewData['products'] = CPU::all();
          break;
        case 'Motherboard':
          $viewData['products'] = Motherboard::all();
          break;
        case 'HardDisk':
          $viewData['products'] = HardDisk::all();
          break;
        case 'Graphic':
          $viewData['products'] = Graphic::all();
          break;
        case 'Power':
          $viewData['products'] = Power::all();
          break;
        case 'Memory':
          $viewData['products'] = Memory::all();
          break;
      }
    
    
    return view(' models.adminLayout.HardwareDatabase')->with('viewData', $viewData);
  } else {
    return redirect()->route('welcome');
  }
  }

  function DeleteHardware($hardware,$id)
  {
    
    if (Auth::user() && Auth::user()->Admin) {
      switch ($hardware) {
        case 'CPU':
         
         CPU::where('ID',"=",$id)->delete();
          break;
        case 'Motherboard':
          Motherboard::where('ID',"=",$id)->delete();
          break;
        case 'HardDisk':
           HardDisk::where('ID',"=",$id)->delete();
          break;
        case 'Graphic':
           Graphic::where('ID',"=",$id)->delete();
          break;
        case 'Power':
           Power::where('ID',"=",$id)->delete();
          break;
        case 'Memory':
           Memory::where('ID',"=",$id)->delete();
          break;
      }
    return back();
    } else {
      return redirect()->route('welcome');
    }

  }

  function AddHardware($hardware){
    $viewData = array();
    $viewData['title']  = "Add Hardware";
    $viewData['productsName'] = $hardware;
    if (Auth::user() && Auth::user()->Admin) {
    
    return view('models.adminLayout.addHardware')->with('viewData',$viewData);
    } else {
      return redirect()->route('welcome');
    }
  
  }

  function SaveHardware(Request $postData,$hardware){
    if (Auth::user() && Auth::user()->Admin) {
      switch ($hardware) {
        case 'CPU':
          $nHareware = new CPU();
          break;
        case 'Motherboard':
          $nHareware = new Motherboard();
          break;
        case 'HardDisk':
          $nHareware = new HardDisk();
          break;
        case 'Graphic':
          $nHareware = new Graphic();
          break;
        case 'Power':
          $nHareware = new Power();
          break;
        case 'Memory':
          $nHareware = new Memory();
          break;
      }
      $nHareware->ID = $postData->ID;
      $nHareware->Name = $postData->name;
      $nHareware->Price = $postData->Price;
      $nHareware->ImageURL = URL('images/HarewareImg.jpg');
      $nHareware->URL = $postData->URL;
      $nHareware->save();
      return redirect()->route('HardwareDatabase',$hardware);
    } else {
      return redirect()->route('welcome');
    }
  }

  function EditHardware($hardware,$id){
    $viewData = array();
    $viewData['title']  = "Edit Hardware";
    $viewData['productsName'] = $hardware;
    if (Auth::user() && Auth::user()->Admin) {
      switch ($hardware) {
        case 'CPU':
          $viewData['product'] = CPU::FindOrFail($id);
          break;
        case 'Motherboard':
          $viewData['product'] = Motherboard::FindOrFail($id);
          break;
        case 'HardDisk':
          $viewData['product'] = HardDisk::FindOrFail($id);
          break;
        case 'Graphic':
          $viewData['product'] = Graphic::FindOrFail($id);
          break;
        case 'Power':
          $viewData['product'] = Power::FindOrFail($id);
          break;
        case 'Memory':
          $viewData['product'] = Memory::FindOrFail($id);
          break;
      }
    return view('models.adminLayout.editHardware')->with('viewData',$viewData);
    } else {
      return redirect()->route('welcome');
    }
  
  }

  function UpdateHardware(Request $postData,$hardware){
    if (Auth::user() && Auth::user()->Admin) {
      switch ($hardware) {
        case 'CPU':
          $nHareware = CPU::Findorfail($postData->ID);
          break;
        case 'Motherboard':
          $nHareware = Motherboard::Findorfail($postData->ID);
          break;
        case 'HardDisk':
          $nHareware =  HardDisk::Findorfail($postData->ID);
          break;
        case 'Graphic':
          $nHareware =  Graphic::Findorfail($postData->ID);
          break;
        case 'Power':
          $nHareware =  Power::Findorfail($postData->ID);
          break;
        case 'Memory':
          $nHareware =  Memory::Findorfail($postData->ID);
          break;
      }

      $nHareware->Name = $postData->name;
      $nHareware->Price = $postData->Price;
      $nHareware->ImageURL = $postData->ImageURL;
      $nHareware->URL = $postData->URL;
      $nHareware->save();
 

      return redirect()->route('HardwareDatabase',$hardware);
    } else {
      return redirect()->route('welcome');
    }
  }
  function CreateUser(Request $postData){
    $postData->validate([
      'name' => 'required',
      'email' => 'required|email|unique:users,email',
      'password' => 'confirmed'
    ]);
    $user = new User();
    $user->name = $postData->name;
    $user->email = $postData->email;
    $user->password = Hash::make($postData->password);
    $user->Admin = isset($postData->Admin);
    $user->save();
   return redirect()->route('Userdatabase');
  }
}