
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title',$viewData['title']); ?>


<link rel="stylesheet" href=<?php echo e(URL('css/card.css')); ?> type="text/css">
<div class="field">
  <label class="label" >Name</label>
  <div class="control">
    <input class="input" type="text" name="Name" value="<?php echo e($viewData['Name']); ?>" placeholder="Text input">
  </div>
</div>

<div class="field">
  <label class="label">Description</label>
  <div class="control">
    <textarea class="textarea" name="Description"  placeholder="Textarea"><?php echo e($viewData['Description']); ?></textarea>
  </div>
</div>
<div class="container">	
       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="<?php echo e($viewData['CPU']->ImageURL); ?>" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5"><?php echo e($viewData['CPU']->Name); ?></p>
						<p class="subtitle is-6"><?php echo e(($viewData['CPU']->Price!=NULL)? $viewData['CPU']->Price."$": "unavailable"); ?></p>
						
							<button class="button is-info" >Edit</button>
						</form>
					</div>
				</div>

				<div class="content">
					
					<a href="<?php echo e($viewData['CPU']->URL); ?>">View Product Page</a>	
				</div>
			</div>
		</div>


      
       
	</div>
</div>
</form>



<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/editComputer.blade.php ENDPATH**/ ?>