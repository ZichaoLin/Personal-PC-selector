
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title',$viewData['title']); ?>

<section class="section">
<form class="box" method="POST" action="<?php echo e(route('SaveHardware',$viewData['productsName'])); ?>">
<?php echo csrf_field(); ?>  
<div class="field">
<label class="label">ID</label>
            <div class="control">
                <input class="input" name="ID" type="text" placeholder="ID" required>
            </div>
 </div>
<div class="field">
<label class="label">Title</label>
            <div class="control">
                <input class="input" name="name" type="name" placeholder="Title" required>
            </div>
 </div>
 <div class="field">
<label class="label">Price</label>
            <div class="control">
                <input class="input" name="Price" max="999999.99" step="0.01" type="number" placeholder="Price" required>
            </div>
 </div>
 <div class="field">
<label class="label">URL</label>
            <div class="control">
                <input class="input" name="URL" type="url" placeholder="https://example.com" required>
            </div>
 </div>
 <br>
        <button class="button is-primary">Save</button>

</form>


</section>


<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/adminLayout/addHardware.blade.php ENDPATH**/ ?>