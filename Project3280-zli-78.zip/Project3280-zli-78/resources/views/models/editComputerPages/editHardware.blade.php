@extends("layout.header")
@include("layout.navbar")
@section("title",$viewData['title'])

<link rel="stylesheet" href={{URL('css/card.css')}} type="text/css">
@if(isset($viewData['Products']))
<h1 class="title cardTitle">Select a New {{$viewData['Hardware']}}</h1>

  
<section class="section">
	
	<div class="container">
		
    @foreach($viewData['Products'] as $product)
	
       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$product->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$product->Name}}</p>
						<p class="subtitle is-6">{{($product->Price!=NULL)? $product->Price."$": "unavailable"}}</p>
						<form id="sendData" method="POST" action="{{route('ChangeHardware')}}">
     						@csrf
     						
							   <input type="hidden" name="ID" value="{{$product->ID}}">
                                <input type="hidden" name="computerId" value="{{$id}}">
                                <input type="hidden" name="Hardware" value="{{$viewData['Hardware']}}">

							@if($product->Price!=NULL)
							<button class="button is-info" >Select</button>
                            @else
                            @endif
						</form>
					</div>
				</div>

				<div class="content">
					
					<a href="{{$product->URL}}">View Product Page</a>	
				</div>
			</div>
		</div>


        @endforeach	
       
	</div>
	</section>
	
	@else
		<article class="message is-danger">
  <div class="message-header">
    <p>Error</p>
    <button class="delete" aria-label="delete"></button>
  </div>
  <div class="message-body ">
  	No products found, please confirm whether the <strong>keywords</strong> are correct.
  </div>
</article>
	@endif		

@extends("layout.footer")