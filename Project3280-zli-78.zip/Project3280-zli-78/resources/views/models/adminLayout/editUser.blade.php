@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])
<div style="margin: 8%;">
    <h1 class="title has-text-centered">Edit for User {{$viewData['user']->name}}</h1>
    <form class="box" method="POST" action="{{ route('UserEditPage',$viewData['user']->id) }}">
        @csrf
        <div class="field">
            <label class="label">Name</label>
            <div class="control">
                <input class="input" name="name" type="name" placeholder="e.g. alex" value={{$viewData['user']->name}}>
                @error('name')
                <span class="has-text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <div class="field">
            <label class="label">Email</label>
            <div class="control">
                <input class="input" name="email" type="email" placeholder="e.g. alex@example.com" value={{$viewData['user']->email}}>
                @error('email')
                <span class="has-text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <div class="field">
            <label class="label">New Password</label>
            <div class="control">
                <input class="input" name="new_password" type="password" placeholder="********">
                @error('new_password')
                <span class="has-text-danger">{{ $message }}</span>
                @enderror
            </div>
        </div>
        <div class="field">
            <label class="label">Confirm Password</label>
            <div class="control">
                <input class="input" name="new_password_confirmation" type="password" placeholder="********">
            </div>
        </div>
        <input class="form-check-input" type="checkbox" name="Admin" id="Admin" {{ $viewData['user']->Admin ? 'checked' : '' }}>
        <label for="Admin">
        <span>Admin</span>
    </label>
    <br>
        <button class="button is-primary">Save</button>
    </form>
</div>
@extends('layout.footer')