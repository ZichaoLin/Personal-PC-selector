<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.4/css/bulma.min.css">
<nav class="navbar" role="navigation" aria-label="main navigation">
  <div class="navbar-brand">
    <a class="navbar-item" href="">
      <img src={{URL("images/icon.png")}} width="60" height="40">
    </a>

    <a role="button" class="navbar-burger" aria-label="menu" aria-expanded="false" data-target="navbarBasicExample">
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
      <span aria-hidden="true"></span>
    </a>
  </div>

  <div id="navbarBasicExample" class="navbar-menu" >
    <div class="navbar-start mr-0">
      <a class="navbar-item" href="{{route('welcome')}}">
        Home
      </a>

      <a class="navbar-item" href="{{route('addComputerPage')}}">
        Build a Computer
      </a>

      <div class="navbar-item has-dropdown is-hoverable">
        <a class="navbar-link">
          More
        </a>

        <div class="navbar-dropdown">
          <a class="navbar-item" href="{{route('ViewComputers')}}">
            View my computers
          </a>
          <a class="navbar-item" href="{{route('CompareComputer')}}">
            Compare computers
          </a>
          <a class="navbar-item" href="{{route('products')}}">
            Look for Hardware
          </a>
          <hr class="navbar-divider">
          <a class="navbar-item" href="https://discord.gg/Y683GqrSS7">
            Contact us
          </a>
        </div>

      </div>
      @if(Auth::user()&&Auth::user()->Admin)
      <div class="navbar-item has-dropdown is-hoverable">
      <a class="navbar-link has-text-danger"  >
        Admin Option
      </a>
      <div class="navbar-dropdown">
          <a class="navbar-item" href="{{route('Userdatabase')}}">
            View user database
          </a>
         
          <a class="navbar-item" href="{{route('ComputerDatabase')}}">
            View Computers database
          </a>
          <a class="navbar-item" href="{{route('HardwareDatabase','CPU')}}">
            View Hardwares database
          </a>
          <hr class="navbar-divider">
          <a class="navbar-item" href="{{route('CreateUserPage')}}">
            Create user
          </a>
      </div>
      </div>
      @endif
    </div>
    <div style="margin: auto;">
      @if(Auth::user())
      @if(Auth::user()->Admin)
      <h1 class="title">Welcome! Admin {{Auth::user()->name}}</h1>
      @else
      <h1 class="title">Welcome {{Auth::user()->name}}</h1>
      @endif
      @else
      <h1 class="title">Welcome Guest</h1>
      @endif
    </div>
    <div class="navbar-end">
      <div class="navbar-item">
        @guest
        @else
        <span>Edit profile</span>
        <a class="navbar-item" href="{{route('Profilepage')}}">
          <img src={{URL("images/edit_icon.png")}} width="40" height="30">
        </a>
        @endguest
        <div class="buttons">
          @guest
          <a class="button is-primary" href="{{ route('register') }}">
            <strong>Sign up</strong>
          </a>
          <a class="button is-light" href=" {{ route('login') }}">
            Log in
          </a>
          @else
          <a href=" {{ route('logout') }}" class="button is-ligh">Logout</a>
          @endguest
        </div>
      </div>
    </div>
  </div>
</nav>