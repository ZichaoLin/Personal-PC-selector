
<?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('title',$viewData['title']); ?>
<section class="section p-0">
    <div class="box">
<table class="table">
    <h1 class="title has-text-centered">Database have <?php echo e(count($viewData['Computers'])); ?> computer(s)</h1>
    <thead>
        <tr>
           <th>Owner</th>
            <th>Name</th>
            <th>Description</th>
            <th>Motherboard</th>
            <th>Power</th>
            <th>Graphics_card</th>
            <th>HardDisk</th>
            <th>CPU</th>
            <th>Memory</th>
            <th>Price</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tfoot>
        <tr>
        <th>Owner</th>
            <th>Name</th>
            <th>Description</th>
            <th>Motherboard</th>
            <th>Power</th>
            <th>Graphics_card</th>
            <th>HardDisk</th>
            <th>CPU</th>
            <th>Memory</th>
            <th>Price</th>
            <th></th>
            <th></th>
        </tr>
    </tfoot>
    <tbody>
        <?php if(isset($viewData['Computers'])): ?>
        <?php $__currentLoopData = $viewData['Computers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
           <td><?php echo e($comp->UserName); ?><br><?php echo e("ID:".$comp->UserId); ?></td>
            <td><?php echo e($comp->Name); ?></td>
           <td><?php echo e($comp->Description); ?></td>
            <td><?php echo e($comp->motherboardName); ?></td>
            <td><?php echo e($comp->powerName); ?></td>
            <td><?php echo e($comp->graphicName); ?></td>
            <td><?php echo e($comp->harddiskName); ?></td>
            
            <td><?php echo e($comp->CPUName); ?></td>
            <td><?php echo e($comp->memoryName); ?></td>
            <td><?php echo e($comp->CPUPrice+
                $comp->GraphicsPrice+
                $comp->HardDiskPrice+
                $comp->MemoriePrice+
                $comp->MotherboardPrice+
                $comp->PowerPrice); ?></td>
          
            <td>
                <a href="<?php echo e(route('EditComputer',$comp->id)); ?>" class="button is-info"> Edit</a>


            </td>
            
            <td>
                
                <a href="<?php echo e(route('DeleteComputer',$comp->id)); ?>" class="button is-danger">Delete</a>


            </td>

            </td>
          
          
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody>
</table>
</div>
</section>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\Project3280-12-01\resources\views/models/adminLayout/computerDatabase.blade.php ENDPATH**/ ?>