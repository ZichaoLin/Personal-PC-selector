<?php

use Illuminate\Support\Facades\Route;

use App\Models\User;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//public routes
Route::get('/', "App\Http\Controllers\UserController@userLogin")->name('login');
Route::get('/welcome', 'App\Http\Controllers\UserController@welcome')->name('welcome');
Route::post('/', "App\Http\Controllers\UserController@Login")->name('Login');
Auth::routes();

route::get('/logout', 'App\Http\Controllers\Auth\LoginController@logout')->name('logout');
route::get('/products', "App\Http\Controllers\UserController@products")->name('products');
//user routes
route::get('/EditProfile', "App\Http\Controllers\UserController@Profilepage")->name('Profilepage');
route::post('/EditProfile', "App\Http\Controllers\UserController@EditProfile")->name('EditProfile');
route::get('/ViewComputers', "App\Http\Controllers\ComputerController@ViewComputers")->name('ViewComputers');
route::get('/ViewComputers/{id}', "App\Http\Controllers\ComputerController@DeleteComputer")->name('DeleteComputer');

//editComputer
route::get('/EditComputer/{id}', "App\Http\Controllers\ComputerController@EditComputer")->name('EditComputer');
route::post('/EditComputer/{id}', "App\Http\Controllers\ComputerController@EditComputerinfo")->name('EditComputerinfo');
route::post('/EditComputerHardware/{id}', "App\Http\Controllers\ComputerController@EditComputerHardware")->name('EditComputerHardware');
route::post('/ChangeHardware', "App\Http\Controllers\ComputerController@ChangeHardware")->name('ChangeHardware');

//compareComputer
route::get('/CompareComputer', "App\Http\Controllers\UserController@CompareComputer")->name('CompareComputer');
route::post('/CompareComputer', "App\Http\Controllers\UserController@Compare")->name('Compare');

//Admin routes
route::get('/Userdatabase', "App\Http\Controllers\AdminController@Userdatabase")->name('Userdatabase');
Route::get('{id}/UserEdit', 'App\Http\Controllers\AdminController@UserEditPage')->name('UserEditPage');
Route::get('{id}/UserDelete', 'App\Http\Controllers\AdminController@UserDelete')->name('UserDelete');
Route::post('{id}/UserEdit', 'App\Http\Controllers\AdminController@UserEdit')->name('UserEdit');
route::get('/ComputerDatabase', "App\Http\Controllers\AdminController@ComputerDatabase")->name('ComputerDatabase');
route::get('/CreateUser', "App\Http\Controllers\AdminController@CreateUserPage")->name('CreateUserPage');
route::post('/CreateUser', "App\Http\Controllers\AdminController@CreateUser")->name('CreateUser');
route::get('/HardwareDatabase/{hardware}', "App\Http\Controllers\AdminController@HardwareDatabase")->name('HardwareDatabase');
route::get('/DeleteHardware/{hardware}/{id}', "App\Http\Controllers\AdminController@DeleteHardware")->name('DeleteHardware');
route::get('/AddHardware/{hardware}', "App\Http\Controllers\AdminController@AddHardware")->name('AddHardware');
route::post('/AddHardware/{hardware}', "App\Http\Controllers\AdminController@SaveHardware")->name('SaveHardware');
route::get('/EditHardware/{hardware}/{id}', "App\Http\Controllers\AdminController@EditHardware")->name('EditHardware');
route::post('/EditHardware/{hardware}/{id}', "App\Http\Controllers\AdminController@UpdateHardware")->name('UpdateHardware');



//addComputerPage
route::get('/addComputerPage', "App\Http\Controllers\ComputerController@addComputerPage")->name('addComputerPage');
route::post('/addComputerPage', "App\Http\Controllers\ComputerController@addHardware")->name('addHardware');

