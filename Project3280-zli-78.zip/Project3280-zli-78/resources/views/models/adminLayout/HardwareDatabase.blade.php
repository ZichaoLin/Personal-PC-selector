@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])
<link rel="stylesheet" href={{URL('css/card.css')}} type="text/css">
<section class="section ">
    <div class="box">
<div class="has-text-centered ">
    <p class="title">Hardware Database</p>

<div class="tabs">
  <ul>
    <li class={{$viewData['productsName']=='CPU'? 'is-active' : ''}}><a href="{{route('HardwareDatabase','CPU')}}">CPU</a></li>
    <li class={{$viewData['productsName']=='Motherboard'? 'is-active' : ''}}><a href="{{route('HardwareDatabase','Motherboard')}}">Motherboard</a></li>
    <li class={{$viewData['productsName']=='Graphic'? 'is-active' : ''}}><a href="{{route('HardwareDatabase','Graphic')}}">Graphic Card</a></li>
    <li class={{$viewData['productsName']=='Power'? 'is-active' : ''}}><a href="{{route('HardwareDatabase','Power')}}">Power</a></li>
    <li class={{$viewData['productsName']=='Memory'? 'is-active' : ''}}><a href="{{route('HardwareDatabase','Memory')}}">Memory</a></li>
    <li class={{$viewData['productsName']=='HardDisk'? 'is-active' : ''}}><a href="{{route('HardwareDatabase','HardDisk')}}">HardDisk</a></li>
  </ul>
</div>
</div>
@if(isset($viewData['products']))
<section class="section">
<div class="container">
@foreach($viewData['products'] as $product)

       	<!-- 	Card	 -->
           <div class="card">
			<div class="card-image">
				<figure class="image is-4by3">
					<img src="{{$product->ImageURL}}" alt="Placeholder image">
				</figure>
			</div>
			<div class="card-content">
				<div class="media">
					<div class="media-left">
					</div>
					<div class="media-content">
						<p class="title is-5">{{$product->Name}}</p>
						<p class="subtitle is-6">{{($product->Price!=null)? $product->Price: "unavailable"}}</p>
					</div>
				</div>

				<div class="content">
					
					<a class="button is-danger" href="{{route('DeleteHardware',[$viewData['productsName'],$product->ID])}}">Delete</a>
                    <a class="button is-info" href="{{route('EditHardware',[$viewData['productsName'],$product->ID])}}">Edit</a>		
				</div>
			</div>
		</div>


        @endforeach	
        <div class="card has-text-centered">
       
			<div class="card-content">
			

				<div class="content">
                <a class="button is-primary " href="{{route('AddHardware',$viewData['productsName'])}}">Add</a>
              
				</div>
			</div>
        	</div>
        
</div>   
</section>
	@else
		<article class="message is-danger">
  <div class="message-header">
    <p>Error</p>
    <button class="delete" aria-label="delete"></button>
  </div>
  <div class="message-body ">
  	No products found, please Add product to database<strong></strong> 
  </div>
</article>
	@endif		




    </div>
</section>


@extends('layout.footer')