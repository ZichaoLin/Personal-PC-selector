@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])

<section class="section">
<form class="box" method="POST" action="{{route('SaveHardware',$viewData['productsName'])}}">
@csrf  
<div class="field">
<label class="label">ID</label>
            <div class="control">
                <input class="input" name="ID" type="text" placeholder="ID" required>
            </div>
 </div>
<div class="field">
<label class="label">Title</label>
            <div class="control">
                <input class="input" name="name" type="name" placeholder="Title" required>
            </div>
 </div>
 <div class="field">
<label class="label">Price</label>
            <div class="control">
                <input class="input" name="Price" max="999999.99" step="0.01" type="number" placeholder="Price" required>
            </div>
 </div>
 <div class="field">
<label class="label">URL</label>
            <div class="control">
                <input class="input" name="URL" type="url" placeholder="https://example.com" required>
            </div>
 </div>
 <br>
        <button class="button is-primary">Save</button>

</form>


</section>

@extends('layout.footer')