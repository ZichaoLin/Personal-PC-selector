@extends('layout.header')
@include('layout.navbar')
@section('title',$viewData['title'])
<section class="section " >
    <div class="box">
<h1 class="title has-text-centered">Users Database</h1>
<table class="table m-auto ">
    
    <thead>
        <tr>
            <th><abbr title="id">id</abbr></th>
            <th>Name</th>
            <th>Email</th>
            <th>permission</th>
            <th>Create date</th>
            <th>Last Update</th>
            <th></th>
            <th></th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th><abbr title="id">id</abbr></th>
            <th>Name</th>
            <th>Email</th>
            <th>permission</th>
            <th>Create date</th>
            <th>Last Update</th>
            <th></th>
            <th></th>
        </tr>
    </tfoot>
    <tbody>
        @foreach($viewData['Users'] as $user)
        <tr>
            <th>{{$user->id}}</th>
            <td>{{$user->name}}
            </td>
            <td>{{$user->email}}</td>
            @if($user->Admin)
            <td>Admin</td>
            @else
            <td>User</td>
            @endif
            <th>{{$user->created_at}}</th>
            <th>{{$user->updated_at}}</th>
          
          
            <td>
                <a href="{{ route('UserEditPage',$user->id)}}" class="button is-info"> edit</a>


            </td>
            <td>
                <a href="{{ route('UserDelete',$user->id)}}" class="button is-danger">delete</a>


            </td>

            </td>
          
          
        </tr>
        @endforeach

    </tbody>
</table>
</div>
</section>
@extends('layout.footer')