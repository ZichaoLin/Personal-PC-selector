<?php $__env->startSection('title',$viewData['title']); ?>
<?php $__env->startSection('head',$viewData['head']); ?>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\i\Desktop\project-3280\resources\views/home.blade.php ENDPATH**/ ?>